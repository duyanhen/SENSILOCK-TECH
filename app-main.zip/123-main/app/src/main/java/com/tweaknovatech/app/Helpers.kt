package com.tweaknovatech.app

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import rikka.shizuku.Shizuku

data class ShellResult(val success: Boolean, val output: String, val error: String = "")
enum class ShizukuStatus { NOT_RUNNING, NO_PERMISSION, READY }

object ShizukuHelper {
    private const val TAG = "Shizuku"
    private const val RC = 1001
    private var permCb: ((Boolean) -> Unit)? = null

    private val onPerm  = Shizuku.OnRequestPermissionResultListener { c, r -> if (c == RC) permCb?.invoke(r == PackageManager.PERMISSION_GRANTED) }
    private val onBound = Shizuku.OnBinderReceivedListener { Log.d(TAG, "OK") }
    private val onDead  = Shizuku.OnBinderDeadListener    { Log.w(TAG, "Dead") }

    fun init() {
        Shizuku.addBinderReceivedListenerSticky(onBound)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }
    fun destroy() {
        Shizuku.removeBinderReceivedListener(onBound)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
    }

    fun isRunning()     = try { Shizuku.pingBinder() } catch (_: Exception) { false }
    fun hasPermission() = try { !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Exception) { false }
    fun getStatus()     = when { !isRunning() -> ShizukuStatus.NOT_RUNNING; !hasPermission() -> ShizukuStatus.NO_PERMISSION; else -> ShizukuStatus.READY }
    fun requestPermission(cb: (Boolean) -> Unit) { permCb = cb; try { Shizuku.requestPermission(RC) } catch (_: Exception) { cb(false) } }

    fun exec(cmd: String): ShellResult {
        if (!isRunning())     return ShellResult(false, "", "Shizuku chưa chạy")
        if (!hasPermission()) return ShellResult(false, "", "Chưa có quyền")
        return try {
            val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText().trim()
            val err = p.errorStream.bufferedReader().readText().trim()
            val code = p.waitFor(); p.destroy()
            Log.d(TAG, "exit=$code cmd=$cmd err=$err")
            ShellResult(code == 0, out, err)
        } catch (e: Exception) {
            Log.e(TAG, "exec: ${e.message}")
            ShellResult(false, "", e.message ?: "Lỗi")
        }
    }
}

object ModuleManager {
    fun run(ctx: Context, id: String, on: Boolean): ShellResult {
        val f = if (on) "${id}_on.sh" else "${id}_off.sh"
        val script = try { ctx.assets.open("modules/$f").bufferedReader().readText() }
                     catch (_: Exception) { return ShellResult(false, "", "Không có file: $f") }
        val cmds = script.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
        if (cmds.isEmpty()) return ShellResult(false, "", "File rỗng!")
        return ShizukuHelper.exec(cmds.joinToString("; "))
    }
}

object KeyManager {
    private const val P = "tweak_key"
    const val FREE = "free"; const val VIP = "vip"; const val NONE = "none"

    fun save(ctx: Context, code: String, tier: String, exp: String, deviceId: String = "") =
        ctx.getSharedPreferences(P, 0).edit()
            .putString("code", code)
            .putString("tier", tier)
            .putString("exp", exp)
            .putString("device", deviceId)
            .apply()

    fun getCode(ctx: Context): String =
        ctx.getSharedPreferences(P, 0).getString("code", "") ?: ""

    fun getDevice(ctx: Context): String =
        ctx.getSharedPreferences(P, 0).getString("device", "") ?: ""

    fun addDevice(ctx: Context, deviceId: String) {
        val p = ctx.getSharedPreferences(P, 0)
        p.edit().putString("device", deviceId).apply()
    }

    fun getTier(ctx: Context): String {
        val p = ctx.getSharedPreferences(P, 0)
        val t = p.getString("tier", NONE) ?: NONE
        val e = p.getString("exp", "") ?: ""
        if (t == NONE) return NONE
        if (e.isNotEmpty()) try {
            val pts = e.split("-")
            if (pts.size == 3) {
                val d = java.util.Calendar.getInstance().apply {
                    set(pts[0].toInt(), pts[1].toInt() - 1, pts[2].toInt(), 23, 59, 59)
                }.time
                if (java.util.Date().after(d)) { clear(ctx); return NONE }
            }
        } catch (_: Exception) {}
        return t
    }

    fun clear(ctx: Context)    = ctx.getSharedPreferences(P, 0).edit().clear().apply()
    fun isActive(ctx: Context) = getTier(ctx) != NONE

    fun compareTo(a: String, b: String): Int = a.compareTo(b)
}

package com.tweaknovatech.app

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class VerifyResult(
    val status: String,
    val tier: String? = null,
    val expires: String? = null,
    val max: Int? = null
)

object ServerBridge {

    private const val GITHUB_TOKEN = "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"
    private const val GITHUB_API   = "https://api.github.com/repos/ducduytapedit-cmd/123/contents/keys.json"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun init(context: Context) {}
    fun destroy() {}

    fun verifyKey(keyCode: String, deviceId: String, callback: (VerifyResult) -> Unit) {
        scope.launch {
            val result = fetchAndVerify(keyCode, deviceId)
            withContext(Dispatchers.Main) { callback(result) }
        }
    }

    private fun fetchAndVerify(keyCode: String, deviceId: String): VerifyResult {
        return try {
            val (arr, sha) = fetchKeysJson() ?: return VerifyResult("error")

            for (i in 0 until arr.length()) {
                val k = arr.getJSONObject(i)
                val code = k.optString("code", "").uppercase()
                if (code != keyCode.trim().uppercase()) continue

                if (!k.optBoolean("isActive", true)) return VerifyResult("revoked")

                // Kiem tra han su dung
                val expiresStr = k.optString("expires", "")
                if (expiresStr.isNotEmpty()) {
                    try {
                        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
                        sdf.timeZone = TimeZone.getTimeZone("UTC")
                        val expDate = sdf.parse(expiresStr)
                        if (expDate != null && Date().after(expDate)) return VerifyResult("expired")
                    } catch (_: Exception) {}
                }

                // Kiem tra device
                val maxDevices = k.optInt("maxDevices", 1)
                val usedArr = k.optJSONArray("usedDevices") ?: JSONArray()
                val usedList = mutableListOf<String>()
                for (j in 0 until usedArr.length()) usedList.add(usedArr.getString(j))

                if (!usedList.contains(deviceId)) {
                    if (usedList.size >= maxDevices) {
                        return VerifyResult("device_limit", max = maxDevices)
                    }
                    // Them device moi vao danh sach
                    usedList.add(deviceId)
                    val newUsed = JSONArray(usedList)
                    k.put("usedDevices", newUsed)
                    arr.put(i, k)
                    // Ghi lai len GitHub
                    pushKeysJson(arr, sha)
                }

                val tier = k.optString("tier", "free")
                val expShort = expiresStr.take(10)
                return VerifyResult("ok", tier = tier, expires = expShort)
            }

            VerifyResult("not_found")
        } catch (e: Exception) {
            VerifyResult("error")
        }
    }

    private fun fetchKeysJson(): Pair<JSONArray, String>? {
        return try {
            val url = URL("$GITHUB_API?t=${System.currentTimeMillis()}")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.requestMethod = "GET"
            conn.setRequestProperty("Authorization", "token $GITHUB_TOKEN")
            conn.setRequestProperty("Accept", "application/vnd.github.v3+json")
            conn.setRequestProperty("Cache-Control", "no-cache")

            if (conn.responseCode != 200) return null

            val response = conn.inputStream.bufferedReader().readText()
            conn.disconnect()

            val obj = JSONObject(response)
            val sha = obj.getString("sha")
            val encoded = obj.getString("content").replace("\n", "")
            val decoded = String(android.util.Base64.decode(encoded, android.util.Base64.DEFAULT))
            Pair(JSONArray(decoded), sha)
        } catch (e: Exception) { null }
    }

    private fun pushKeysJson(arr: JSONArray, sha: String) {
        try {
            val content = android.util.Base64.encodeToString(
                arr.toString(2).toByteArray(Charsets.UTF_8),
                android.util.Base64.NO_WRAP
            )
            val body = JSONObject().apply {
                put("message", "Update usedDevices")
                put("content", content)
                put("sha", sha)
            }
            val url = URL(GITHUB_API)
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.requestMethod = "PUT"
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "token $GITHUB_TOKEN")
            conn.setRequestProperty("Accept", "application/vnd.github.v3+json")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.write(body.toString().toByteArray(Charsets.UTF_8))
            conn.responseCode // trigger request
            conn.disconnect()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

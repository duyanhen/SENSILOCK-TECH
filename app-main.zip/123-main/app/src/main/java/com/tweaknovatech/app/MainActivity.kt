package com.tweaknovatech.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import androidx.lifecycle.*
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

//  COLORS (y đúc HTML) 
val C_CYAN    = Color(0xFF00F5FF)
val C_CYAN2   = Color(0xFF00C8D4)
val C_PINK    = Color(0xFFFF006E)
val C_PINK2   = Color(0xFFCC0058)
val C_GREEN   = Color(0xFF00FF88)
val C_YELLOW  = Color(0xFFFFE94D)
val C_RED     = Color(0xFFFF3366)
val C_PURPLE  = Color(0xFF7C00FF)
val C_BG      = Color(0xFF050812)
val C_BG2     = Color(0xFF080D1A)
val C_CARD    = Color(0xFF0A0F1E)
val C_CARD2   = Color(0xFF0E1525)
val C_BORDER  = Color(0xFF00F5FF).copy(alpha = 0.1f)
val C_BORDER2 = Color(0xFF00F5FF).copy(alpha = 0.22f)
val C_TEXT    = Color(0xFFDFF4FF)
val C_TEXT2   = Color(0xFF6AB0C8)
val C_TEXT3   = Color(0xFF2A4558)

//  ENUMS 
enum class AppScreen { SPLASH, KEY, MAIN }
enum class NavTab { HOME, FEATURES, STATS, INFO }
enum class KeyTier { NONE, FREE, VIP }

//  DATA 
data class FeatureData(
    val id: String,
    val title: String,
    val desc: String,
    val icon: ImageVector,
    val accent: Color,
    val tier: KeyTier = KeyTier.FREE,
    val enabled: Boolean = false,
    val loading: Boolean = false
)

//  VIEWMODEL 
class MainViewModel : ViewModel() {
    private val _screen  = MutableStateFlow(AppScreen.SPLASH)
    private val _tab     = MutableStateFlow(NavTab.HOME)
    private val _tier    = MutableStateFlow(KeyTier.NONE)
    private val _features= MutableStateFlow(initFeatures())
    private val _shizuku = MutableStateFlow(ShizukuStatus.NOT_RUNNING)
    private val _toast   = MutableStateFlow<String?>(null)
    private val _fps     = MutableStateFlow(60)
    private val _cpu     = MutableStateFlow(40)
    private val _ram     = MutableStateFlow(55)
    private val _temp    = MutableStateFlow(36)
    private val _score   = MutableStateFlow(0)
    private val _fpsHist = MutableStateFlow(listOf<Int>())
    private val _cpuHist = MutableStateFlow(listOf<Int>())
    private val _ramHist = MutableStateFlow(listOf<Int>())
    private val _tempHist= MutableStateFlow(listOf<Int>())

    val screen   = _screen.asStateFlow()
    val tab      = _tab.asStateFlow()
    val tier     = _tier.asStateFlow()
    val features = _features.asStateFlow()
    val shizuku  = _shizuku.asStateFlow()
    val toast    = _toast.asStateFlow()
    val fps      = _fps.asStateFlow()
    val cpu      = _cpu.asStateFlow()
    val ram      = _ram.asStateFlow()
    val temp     = _temp.asStateFlow()
    val score    = _score.asStateFlow()
    val fpsHist  = _fpsHist.asStateFlow()
    val cpuHist  = _cpuHist.asStateFlow()
    val ramHist  = _ramHist.asStateFlow()
    val tempHist = _tempHist.asStateFlow()

    private fun initFeatures() = listOf(
        // FREE
        FeatureData("performance", "Chế độ hiệu suất",    "Ép FPS, tối ưu GPU, mở khoá hiệu suất",    Icons.Filled.Speed,               Color(0xFFFF6B35), KeyTier.FREE),
        FeatureData("touch",       "Tăng nhạy cảm ứng",   "Tăng phản hồi cảm ứng, giảm delay thao tác",Icons.Filled.TouchApp,            Color(0xFF00D4FF), KeyTier.FREE),
        FeatureData("ram",         "Tăng RAM & don rác",  "Dọn log, tối ưu RAM, giảm app chạy ngầm",   Icons.Filled.Memory,              Color(0xFF7B2FBE), KeyTier.FREE),
        FeatureData("network",     "Tối ưu Internet",     "Bật TCP/BBR, giảm độ trễ mạng bằng TTL",    Icons.Filled.Wifi,                Color(0xFF00BFA5), KeyTier.FREE),
        // VIP
        FeatureData("fps",         "FPS Boost",           "Buff FPS, tối ưu FPS",       Icons.Filled.Speed,               Color(0xFFFF6B35), KeyTier.VIP),
        FeatureData("optimize",    "Optimize",            "Tối ưu hóa toàn diện hệ thống",             Icons.Filled.AutoFixHigh,         Color(0xFF7B2FBE), KeyTier.VIP),
        FeatureData("fixlag",      "Fix Lag",             "Giảm giật lag game, smooth gameplay",        Icons.Filled.SportsEsports,       Color(0xFF00C851), KeyTier.VIP),
        FeatureData("screenboost", "Screen Boost",        "Buff Màn & Unlock 120Hz",                   Icons.Filled.Tv,                  Color(0xFF00D4FF), KeyTier.VIP),
    )

    fun setScreen(s: AppScreen) = viewModelScope.launch { _screen.emit(s) }
    fun setTab(t: NavTab)       = viewModelScope.launch { _tab.emit(t) }

    fun initFromContext(context: Context) {
        val t = KeyManager.getTier(context)
        val tier = when(t) { "vip"->KeyTier.VIP; "free"->KeyTier.FREE; else->KeyTier.NONE }
        viewModelScope.launch { _tier.emit(tier) }
        viewModelScope.launch(Dispatchers.IO) { _shizuku.emit(ShizukuHelper.getStatus()) }
        startStats()
    }

    // 
    // Verify key qua WebView server (postMessage bridge)
    // 
    fun activateKey(context: Context, keyCode: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val trimmedKey = keyCode.trim().uppercase()
                val thisDevice = android.provider.Settings.Secure.getString(
                    context.contentResolver, android.provider.Settings.Secure.ANDROID_ID
                ) ?: ""

                // Gui postMessage toi WebView server qua ServerBridge
                ServerBridge.verifyKey(trimmedKey, thisDevice) { result ->
                    viewModelScope.launch {
                        when (result.status) {
                            "ok" -> {
                                val tierStr = result.tier ?: "free"
                                val expires = result.expires?.let {
                                    try {
                                        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US)
                                        sdf.timeZone = java.util.TimeZone.getTimeZone("UTC")
                                        val d = sdf.parse(it)
                                        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(d!!)
                                    } catch (_: Exception) { it.take(10) }
                                } ?: "9999-12-31"
                                val tier = if (tierStr == "vip") KeyTier.VIP else KeyTier.FREE
                                KeyManager.save(context, trimmedKey, tierStr, expires, thisDevice)
                                _tier.emit(tier)
                                val label = if (tier == KeyTier.VIP) "VIP" else "FREE"
                                withContext(Dispatchers.Main) { onResult(true, "Kich hoat thanh cong! $label | Het han: $expires") }
                            }
                            "not_found" -> withContext(Dispatchers.Main) { onResult(false, "Key khong ton tai!") }
                            "revoked"   -> withContext(Dispatchers.Main) { onResult(false, "Key da bi thu hoi!") }
                            "expired"   -> withContext(Dispatchers.Main) { onResult(false, "Key da het han!") }
                            "device_limit" -> withContext(Dispatchers.Main) { onResult(false, "Key da dung tren ${result.max} thiet bi!") }
                            else        -> withContext(Dispatchers.Main) { onResult(false, "Loi xac thuc! Thu lai.") }
                        }
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { onResult(false, "Loi: ${e.message?.take(50)}") }
            }
        }
    }

    fun requestShizuku() {
        ShizukuHelper.requestPermission { granted ->
            viewModelScope.launch {
                _shizuku.emit(if (granted) ShizukuStatus.READY else ShizukuStatus.NO_PERMISSION)
                showToast(if (granted) "Da cap quyen Shizuku!" else "Tu choi quyen Shizuku")
            }
        }
    }

    fun toggleFeature(context: Context, id: String) {
        if (_shizuku.value != ShizukuStatus.READY) {
            showToast("Cần kết nối Shizuku trước!"); return
        }
        val f = _features.value.find { it.id == id } ?: return
        // Kiểm tra tier
        if (f.tier == KeyTier.VIP && _tier.value != KeyTier.VIP) {
            showToast("Tính năng này yêu cầu VIP!"); return
        }
        val willEnable = !f.enabled
        viewModelScope.launch(Dispatchers.IO) {
            setFeatureLoading(id, true)
            val result = ModuleManager.run(context, id, willEnable)
            setFeatureState(id, if (result.success) willEnable else f.enabled, false)
            showToast(if (result.success) "${if(willEnable)"Đã bật" else "Đã tắt"}: ${f.title}" else "Lỗi: ${result.error.take(50)}")
        }
    }

    private suspend fun setFeatureLoading(id: String, loading: Boolean) {
        _features.emit(_features.value.map { if(it.id==id) it.copy(loading=loading) else it })
    }
    private suspend fun setFeatureState(id: String, enabled: Boolean, loading: Boolean) {
        _features.emit(_features.value.map { if(it.id==id) it.copy(enabled=enabled,loading=loading) else it })
    }

    fun showToast(msg: String) = viewModelScope.launch {
        _toast.emit(msg); delay(3000); _toast.emit(null)
    }

    private fun addHist(list: List<Int>, v: Int, max: Int = 20) = (list + v).takeLast(max)

    fun startStats() = viewModelScope.launch {
        var fps=60f; var cpu=40f; var ram=55f; var temp=36f
        while(true) {
            delay(2000)
            fps  = (fps  + (Math.random()-0.45)*8).coerceIn(30.0,120.0).toFloat()
            cpu  = (cpu  + (Math.random()-0.45)*6).coerceIn(5.0,95.0).toFloat()
            ram  = (ram  + (Math.random()-0.45)*3).coerceIn(20.0,90.0).toFloat()
            temp = (temp + (Math.random()-0.45)*2).coerceIn(28.0,65.0).toFloat()
            val fi=fps.toInt(); val ci=cpu.toInt(); val ri=ram.toInt(); val ti=temp.toInt()
            _fps.emit(fi); _cpu.emit(ci); _ram.emit(ri); _temp.emit(ti)
            _fpsHist.emit(addHist(_fpsHist.value,fi)); _cpuHist.emit(addHist(_cpuHist.value,ci))
            _ramHist.emit(addHist(_ramHist.value,ri)); _tempHist.emit(addHist(_tempHist.value,ti))
            _score.emit(((fi/120f*40)+((100-ci)/100f*30)+((100-ri)/100f*20)+((65-ti)/65f*10)).toInt().coerceIn(0,100))
        }
    }
}

//  MAIN ACTIVITY 
class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); enableEdgeToEdge()
        ShizukuHelper.init()
        ServerBridge.init(this)   // Khoi dong WebView server
        setContent { TweakApp() }
    }
    override fun onDestroy() {
        super.onDestroy()
        ShizukuHelper.destroy()
        ServerBridge.destroy()
    }
}

//  ROOT 
@Composable
fun TweakApp(vm: MainViewModel = viewModel()) {
    val screen by vm.screen.collectAsState()
    val toastMsg by vm.toast.collectAsState()
    val ctx = LocalContext.current
    val snackHost = remember { SnackbarHostState() }

    LaunchedEffect(Unit) { vm.initFromContext(ctx) }
    LaunchedEffect(toastMsg) { toastMsg?.let { snackHost.showSnackbar(it, duration = SnackbarDuration.Short) } }

    MaterialTheme(colorScheme = darkColorScheme(primary=C_CYAN, background=C_BG, surface=C_CARD, onBackground=C_TEXT, onSurface=C_TEXT)) {
        Box(Modifier.fillMaxSize().background(C_BG)) {
            // Scanline overlay
            Canvas(Modifier.fillMaxSize()) {
                val lineH = 4.dp.toPx()
                var y = 0f
                while(y < size.height) { drawRect(Color.Black.copy(0.07f), Offset(0f,y+2), Size(size.width,2f)); y+=lineH }
            }
            val ctx2 = LocalContext.current
            when(screen) {
                AppScreen.SPLASH -> SplashScreen(onDone = {
                    if (KeyManager.isActive(ctx2)) vm.setScreen(AppScreen.MAIN)
                    else vm.setScreen(AppScreen.KEY)
                })
                AppScreen.KEY   -> KeyScreen(vm)
                AppScreen.MAIN  -> MainScreen(vm)
            }
            SnackbarHost(snackHost, modifier=Modifier.align(Alignment.BottomCenter).padding(bottom=70.dp)) {
                Snackbar(it, containerColor=C_CARD2, contentColor=C_TEXT, shape=RoundedCornerShape(20.dp), modifier=Modifier.padding(16.dp))
            }
        }
    }
}

// 
// SPLASH — y đúc HTML
// 
@Composable
fun SplashScreen(onDone: () -> Unit) {
    var progress by remember { mutableFloatStateOf(0f) }
    var statusText by remember { mutableStateOf("INITIALIZING SYSTEM...") }
    val msgs = listOf("INITIALIZING SYSTEM...","SECURITY CHECK...","LOADING MODULES...","CONNECTING...","READY!")
    val inf = rememberInfiniteTransition(label="s")
    val hexRot by inf.animateFloat(0f,360f, infiniteRepeatable(tween(12000,easing=LinearEasing)),label="hr")
    val ringS  by inf.animateFloat(1f,1.07f,infiniteRepeatable(tween(2800,easing=EaseInOutSine),RepeatMode.Reverse),label="rs")
    val scanY  by inf.animateFloat(0f,1f,   infiniteRepeatable(tween(3000,easing=LinearEasing)),label="sy")
    val gridOp by inf.animateFloat(0.4f,0.9f,infiniteRepeatable(tween(6000,easing=EaseInOutSine),RepeatMode.Reverse),label="go")

    LaunchedEffect(Unit) {
        while(progress<1f) {
            delay(60); progress=(progress+(0.01f+Math.random().toFloat()*0.02f)).coerceAtMost(1f)
            statusText=msgs[(progress*(msgs.size-1)).toInt().coerceIn(0,msgs.size-1)]
        }
        delay(300); onDone()
    }

    Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF0D1640),C_BG), radius=1200f))) {
        // Grid
        Canvas(Modifier.fillMaxSize().alpha(gridOp)) {
            val step=50.dp.toPx()
            var x=0f; while(x<size.width){drawLine(C_CYAN.copy(0.04f),Offset(x,0f),Offset(x,size.height),1f);x+=step}
            var y=0f; while(y<size.height){drawLine(C_CYAN.copy(0.04f),Offset(0f,y),Offset(size.width,y),1f);y+=step}
        }
        // Scan line
        Box(Modifier.fillMaxWidth().height(1.dp).offset(y=LocalDensity.current.run{(scanY*1000).dp}).background(Brush.horizontalGradient(listOf(Color.Transparent,C_CYAN.copy(0.5f),Color.Transparent))))

        Column(Modifier.fillMaxSize(), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
            // Logo
            Box(Modifier.size(140.dp), contentAlignment=Alignment.Center) {
                // Rings
                listOf(110.dp to 0.55f, 126.dp to 0.28f, 142.dp to 0.12f).forEach { (sz,a) ->
                    Box(Modifier.size(sz*ringS).border(1.dp,C_CYAN.copy(a),CircleShape))
                }
                // Hex spinning
                Canvas(Modifier.size(90.dp).rotate(hexRot)) {
                    val cx=size.width/2; val cy=size.height/2; val r=size.width/2-2
                    val pts=(0..5).map{ i->val a=Math.toRadians(60.0*i-30.0); Offset((cx+r*Math.cos(a)).toFloat(),(cy+r*Math.sin(a)).toFloat()) }
                    drawPath(Path().apply{pts.forEachIndexed{i,p->if(i==0)moveTo(p.x,p.y) else lineTo(p.x,p.y);close()}},C_GREEN.copy(0.15f))
                    for(i in 0..5) drawLine(C_GREEN.copy(0.4f),pts[i],pts[(i+1)%6],1.5f)
                    drawCircle(C_GREEN,8f,Offset(cx,cy))
                    drawCircle(Brush.radialGradient(listOf(C_GREEN.copy(0.4f),Color.Transparent)),30f,Offset(cx,cy))
                }
            }
            Spacer(Modifier.height(16.dp))
            // Title
            Text("TWEAK NOVA TECH", style=TextStyle(fontSize=28.sp, fontWeight=FontWeight.Black, letterSpacing=6.sp, brush=Brush.horizontalGradient(listOf(C_CYAN,Color(0xFF00FFCC),C_CYAN))))
            Text("OPTIMIZE", color=C_TEXT2, fontSize=11.sp, letterSpacing=14.sp, modifier=Modifier.padding(top=4.dp))
            Text("AI · PERFORMANCE · GAMING", color=C_TEXT3, fontSize=10.sp, letterSpacing=3.sp, modifier=Modifier.padding(top=4.dp))
            Spacer(Modifier.height(28.dp))
            // Loader
            Column(Modifier.width(240.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Box(Modifier.fillMaxWidth().height(2.dp).clip(RoundedCornerShape(1.dp)).background(C_CYAN.copy(0.08f))) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(progress).background(Brush.horizontalGradient(listOf(C_CYAN2,C_CYAN,Color(0xFF00FFCC)))))
                }
                Spacer(Modifier.height(10.dp))
                Text(statusText, color=C_CYAN2, fontSize=10.sp, letterSpacing=2.sp)
            }
            Spacer(Modifier.height(8.dp))
            Text("v2.0.1 — BUILD 2026", color=C_TEXT3, fontSize=9.sp, letterSpacing=2.sp)
        }
    }
}

// 
// KEY SCREEN
// 
@Composable
fun KeyScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var keyText by remember { mutableStateOf("") }
    var msgText by remember { mutableStateOf("") }
    var msgColor by remember { mutableStateOf(C_TEXT3) }
    var loading by remember { mutableStateOf(false) }
    val inf = rememberInfiniteTransition(label="km")
    val gridOp by inf.animateFloat(0.025f,0.05f,infiniteRepeatable(tween(3000,easing=EaseInOutSine),RepeatMode.Reverse),label="kg")

    Box(Modifier.fillMaxSize().background(C_BG)) {
        Canvas(Modifier.fillMaxSize().alpha(gridOp)) {
            val step=44.dp.toPx()
            var x=0f;while(x<size.width){drawLine(C_CYAN,Offset(x,0f),Offset(x,size.height),1f);x+=step}
            var y=0f;while(y<size.height){drawLine(C_CYAN,Offset(0f,y),Offset(size.width,y),1f);y+=step}
        }
        Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally, modifier=Modifier.padding(24.dp)) {
                // Modal box
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF0A0F1E),Color(0xFF0E1525)))).border(1.dp,C_BORDER2,RoundedCornerShape(22.dp)).padding(32.dp,28.dp)) {
                    // Corner accents
                    Canvas(Modifier.fillMaxWidth().height(0.dp)) {
                        drawLine(C_CYAN,Offset(0f,0f),Offset(14.dp.toPx(),0f),1.5f)
                        drawLine(C_CYAN,Offset(0f,0f),Offset(0f,14.dp.toPx()),1.5f)
                    }
                    Column(horizontalAlignment=Alignment.CenterHorizontally) {
                        Text("🔐", fontSize=46.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("TWEAK NOVA TECH", style=TextStyle(fontSize=16.sp,fontWeight=FontWeight.Bold,letterSpacing=4.sp,brush=Brush.horizontalGradient(listOf(C_CYAN,C_PINK))))
                        Spacer(Modifier.height(6.dp))
                        Text("NHẬP KEY ĐỂ KÍCH HOẠT · MUA KEY LIÊN HỆ ADMIN", color=C_TEXT3, fontSize=10.sp, letterSpacing=2.sp, textAlign=TextAlign.Center)
                        Spacer(Modifier.height(26.dp))
                        OutlinedTextField(
                            value=keyText, onValueChange={keyText=it},
                            placeholder={Text("Nhập key tại đây...",color=C_TEXT3,fontSize=12.sp)},
                            singleLine=true,
                            keyboardOptions=KeyboardOptions(imeAction=ImeAction.Done),
                            keyboardActions=KeyboardActions(onDone={}),
                            modifier=Modifier.fillMaxWidth(),
                            colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=C_CYAN,unfocusedBorderColor=C_BORDER2,focusedTextColor=C_TEXT,unfocusedTextColor=C_TEXT,cursorColor=C_CYAN,unfocusedContainerColor=C_CYAN.copy(0.04f),focusedContainerColor=C_CYAN.copy(0.07f)),
                            shape=RoundedCornerShape(12.dp),
                            textStyle=LocalTextStyle.current.copy(fontSize=13.sp,letterSpacing=2.sp,fontFamily=FontFamily.Monospace)
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(msgText, color=msgColor, fontSize=11.sp, letterSpacing=1.sp, minLines=1)
                        Spacer(Modifier.height(14.dp))
                        Button(
                            onClick={
                                if(!loading && keyText.isNotBlank()) {
                                    loading=true; msgText="Đang xác thực key..."; msgColor=C_TEXT3
                                    vm.activateKey(ctx,keyText) { ok, msg ->
                                        loading=false; msgText=msg
                                        msgColor=if(ok) C_GREEN else C_RED
                                        if(ok) { kotlinx.coroutines.GlobalScope.launch{ kotlinx.coroutines.delay(800); vm.setScreen(AppScreen.MAIN) } }
                                    }
                                }
                            },
                            enabled=!loading,
                            modifier=Modifier.fillMaxWidth().height(52.dp),
                            shape=RoundedCornerShape(14.dp),
                            colors=ButtonDefaults.buttonColors(containerColor=Color.Transparent,disabledContainerColor=Color.Transparent),
                            contentPadding=PaddingValues(0.dp),
                            border=null
                        ) {
                            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(C_CYAN,Color(0xFF00D4E8),Color(0xFF00FFCC)))).padding(16.dp),contentAlignment=Alignment.Center) {
                                if(loading) CircularProgressIndicator(Modifier.size(20.dp),color=C_BG,strokeWidth=2.dp)
                                else Text("KÍCH HOẠT",color=C_BG,fontSize=13.sp,fontWeight=FontWeight.Black,letterSpacing=3.sp)
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent,C_CYAN.copy(0.1f)))))
                            Text("🔒 TWEAK NOVA TECH SECURE", color=C_TEXT3, fontSize=9.sp, letterSpacing=2.sp)
                            Box(Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(C_CYAN.copy(0.1f),Color.Transparent))))
                        }
                    }
                }
            }
        }
    }
}

// 
// MAIN SCREEN
// 
@Composable
fun MainScreen(vm: MainViewModel) {
    val tab by vm.tab.collectAsState()
    val tier by vm.tier.collectAsState()
    val ctx = LocalContext.current

    Scaffold(
        containerColor=C_BG,
        topBar={ TweakTopBar(vm, tier) },
        bottomBar={ TweakBottomNav(tab){ vm.setTab(it) } }
    ) { pad ->
        AnimatedContent(targetState=tab, transitionSpec={fadeIn(tween(180)) togetherWith fadeOut(tween(180))}, label="tab", modifier=Modifier.padding(pad)) { t ->
            when(t) {
                NavTab.HOME     -> HomeTab(vm)
                NavTab.FEATURES -> FeaturesTab(vm, tier)
                NavTab.STATS    -> StatsTab(vm)
                NavTab.INFO      -> InfoTab(ctx, vm)
            }
        }
    }
}

// ── TOP BAR ──────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TweakTopBar(vm: MainViewModel, tier: KeyTier) {
    val shizuku by vm.shizuku.collectAsState()
    val inf = rememberInfiniteTransition(label="dot")
    val dotA by inf.animateFloat(1f,0.3f,infiniteRepeatable(tween(1500),RepeatMode.Reverse),label="da")
    Column {
        TopAppBar(
            title={
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Canvas(Modifier.size(22.dp)) {
                        val cx=size.width/2;val cy=size.height/2;val r=size.width/2-1
                        val pts=(0..5).map{i->val a=Math.toRadians(60.0*i-30.0);Offset((cx+r*Math.cos(a)).toFloat(),(cy+r*Math.sin(a)).toFloat())}
                        for(i in 0..5) drawLine(C_GREEN.copy(0.5f),pts[i],pts[(i+1)%6],2f)
                        drawCircle(C_GREEN,5f,Offset(cx,cy))
                    }
                    Text("TweakNovaTech",style=TextStyle(fontSize=13.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp,color=C_CYAN))
                }
            },
            actions={
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.padding(end=16.dp)) {
                    // Tier badge
                    val (tbg,tc,tt) = when(tier) {
                        KeyTier.VIP  -> Triple(Brush.horizontalGradient(listOf(Color(0xFFFFD700).copy(0.15f),Color(0xFFFF8C00).copy(0.12f))), Color(0xFFFFD700), "VIP")
                        KeyTier.FREE -> Triple(Brush.horizontalGradient(listOf(C_CYAN.copy(0.1f),C_CYAN.copy(0.06f))), C_CYAN, "FREE")
                        else         -> Triple(Brush.horizontalGradient(listOf(C_TEXT3.copy(0.1f),C_TEXT3.copy(0.06f))), C_TEXT3, "NONE")
                    }
                    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(tbg).border(1.dp,tc.copy(0.3f),RoundedCornerShape(20.dp)).padding(horizontal=10.dp,vertical=3.dp)) {
                        Text(tt,color=tc,fontSize=9.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp)
                    }
                    // Status dot
                    val dotColor=when(shizuku){ShizukuStatus.READY->C_GREEN;ShizukuStatus.NO_PERMISSION->C_YELLOW;else->C_RED}
                    Box(Modifier.size(7.dp).background(dotColor.copy(dotA),CircleShape))
                    Text(when(shizuku){ShizukuStatus.READY->"ACTIVE";ShizukuStatus.NO_PERMISSION->"NO PERM";else->"OFFLINE"},color=dotColor,fontSize=9.sp,letterSpacing=1.sp)
                }
            },
            colors=TopAppBarDefaults.topAppBarColors(containerColor=C_BG.copy(0.99f))
        )
        Box(Modifier.fillMaxWidth().height(1.dp).background(C_BORDER))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent,C_PINK.copy(0.4f),C_CYAN.copy(0.4f),Color.Transparent))))
    }
}

// ── BOTTOM NAV ───────────────────────────────────────
@Composable
fun TweakBottomNav(current: NavTab, onTab: (NavTab) -> Unit) {
    val items = listOf(
        Triple(NavTab.HOME,     Icons.Filled.Home,       "HOME"),
        Triple(NavTab.FEATURES, Icons.Filled.Star,       "FEATURES"),
        Triple(NavTab.STATS,    Icons.Filled.BarChart,   "STATS"),
        Triple(NavTab.INFO,      Icons.Filled.Person,     "INFO"),
    )
    Column {
        Box(Modifier.fillMaxWidth().height(1.dp).background(C_BORDER))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent,C_PINK.copy(0.3f),C_CYAN.copy(0.3f),Color.Transparent))))
        NavigationBar(containerColor=C_BG.copy(0.99f),tonalElevation=0.dp) {
            items.forEach { (tab,icon,label) ->
                val sel = current==tab
                NavigationBarItem(
                    selected=sel, onClick={onTab(tab)},
                    icon={ Icon(icon,null,Modifier.size(22.dp),tint=if(sel) C_CYAN else C_TEXT3) },
                    label={ Text(label,fontSize=8.sp,letterSpacing=1.sp,color=if(sel) C_CYAN else C_TEXT3) },
                    colors=NavigationBarItemDefaults.colors(indicatorColor=C_CYAN.copy(0.1f))
                )
            }
        }
    }
}

// 
// HOME TAB
// 
@Composable
fun HomeTab(vm: MainViewModel) {
    val fps by vm.fps.collectAsState(); val cpu by vm.cpu.collectAsState()
    val ram by vm.ram.collectAsState(); val temp by vm.temp.collectAsState()
    val score by vm.score.collectAsState()
    var boosting by remember { mutableStateOf(false) }
    val boostPct by animateIntAsState(if(boosting) 100 else 0, tween(2000), label="bp")
    val scope = rememberCoroutineScope()
    val inf = rememberInfiniteTransition(label="home")
    val boostGlow by inf.animateFloat(0.4f,0.8f,infiniteRepeatable(tween(2000,easing=EaseInOutSine),RepeatMode.Reverse),label="bg")

    LazyColumn(contentPadding=PaddingValues(16.dp,12.dp,16.dp,16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        // Hero
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(C_CYAN.copy(0.04f),C_PINK.copy(0.04f)))).border(1.dp,C_BORDER2,RoundedCornerShape(18.dp)).padding(18.dp)) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Column {
                        Text("SYSTEM",color=C_TEXT,fontSize=20.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp)
                        Text(buildAnnotatedString{withStyle(SpanStyle(brush=Brush.horizontalGradient(listOf(C_CYAN,C_PINK)))){append("OPTIMIZER")}},fontSize=20.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp)
                        Spacer(Modifier.height(6.dp))
                        Text("AI-Powered · Tối ưu hóa thông minh",color=C_TEXT3,fontSize=10.sp,letterSpacing=1.sp)
                    }
                    // Boost button
                    Button(onClick={
                        if(!boosting){boosting=true;scope.launch{delay(2200);boosting=false;vm.showToast("Boost hoàn tất! Hệ thống đã tối ưu!")}}
                    },colors=ButtonDefaults.buttonColors(containerColor=Color.Transparent),contentPadding=PaddingValues(0.dp),modifier=Modifier.size(72.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(C_GREEN.copy(boostGlow),C_CYAN.copy(boostGlow*0.6f))))) {
                        Column(horizontalAlignment=Alignment.CenterHorizontally) {
                            if(boosting) Text("$boostPct%",color=C_BG,fontSize=11.sp,fontWeight=FontWeight.Black)
                            else Icon(Icons.Filled.FlashOn,null,tint=C_BG,modifier=Modifier.size(26.dp))
                            Text(if(boosting)"WAIT" else "BOOST",color=C_BG,fontSize=7.sp,fontWeight=FontWeight.Black,letterSpacing=1.sp)
                        }
                    }
                }
            }
        }

        // Stats grid
        item {
            LazyVerticalGrid(GridCells.Fixed(2),Modifier.height(220.dp),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalArrangement=Arrangement.spacedBy(10.dp),userScrollEnabled=false) {
                items(listOf(
                    listOf("FPS",fps.toString(),fps/120f,C_GREEN,if(fps>90)"EXCELLENT" else if(fps>60)"GOOD" else "LOW"),
                    listOf("CPU","$cpu%",cpu/100f,C_YELLOW,if(cpu>80)"HIGH" else "NORMAL"),
                    listOf("RAM","$ram%",ram/100f,C_CYAN,if(ram>80)"CRITICAL" else "OK"),
                    listOf("TEMP","$temp°",temp/65f,C_RED,if(temp>55)"HOT" else "COOL"),
                )) { (lbl,v,p,c,st) ->
                    @Suppress("UNCHECKED_CAST")
                    val pf = (p as Float); val col = c as Color
                    val animP by animateFloatAsState(pf,tween(1000),label="p")
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=C_CARD),border=BorderStroke(1.dp,C_BORDER)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(lbl as String,color=C_TEXT3,fontSize=9.sp,letterSpacing=3.sp)
                            Text(v as String,color=col,fontSize=26.sp,fontWeight=FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Box(Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)).background(col.copy(0.07f))) {
                                Box(Modifier.fillMaxHeight().fillMaxWidth(animP.coerceIn(0f,1f)).background(Brush.horizontalGradient(listOf(col.copy(0.5f),col))))
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(st as String,color=C_TEXT3,fontSize=9.sp,letterSpacing=1.sp)
                        }
                    }
                }
            }
        }

        // Score
        item {
            val scoreAnim by animateFloatAsState(score/100f,tween(1500),label="sc")
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(C_PURPLE.copy(0.07f),C_CYAN.copy(0.04f)))).border(1.dp,C_PURPLE.copy(0.22f),RoundedCornerShape(18.dp)).padding(18.dp)) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Column {
                        Text("PERFORMANCE SCORE",color=C_TEXT3,fontSize=9.sp,letterSpacing=3.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(score.toString(),style=TextStyle(fontSize=52.sp,fontWeight=FontWeight.Black,brush=Brush.horizontalGradient(listOf(C_GREEN,C_CYAN))))
                        Text(when{score>80->"EXCELLENT";score>60->"GOOD";score>40->"AVERAGE";else->"POOR"},color=C_GREEN,fontSize=11.sp,letterSpacing=2.sp)
                    }
                    Canvas(Modifier.size(80.dp)) {
                        val sw=6.dp.toPx()
                        drawArc(Color(0xFF0A2A1A),-90f,360f,false,style=Stroke(sw))
                        drawArc(C_GREEN,-90f,scoreAnim*360f,false,style=Stroke(sw,cap=StrokeCap.Round))
                    }
                }
            }
        }

        // Quick actions
        item { Text("Quick Actions",color=C_TEXT3,fontSize=10.sp,letterSpacing=2.sp,fontWeight=FontWeight.SemiBold) }
        item {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                listOf(Icons.Filled.DeleteSweep to "Clear RAM", Icons.Filled.AcUnit to "Cool Down", Icons.Filled.FlashOn to "FPS Boost", Icons.Filled.Wifi to "Net Fix")
                    .forEachIndexed { i, (icon,lbl) ->
                        val msgs = listOf("Đã dọn RAM!","Đang làm mát...","FPS Boost đã áp dụng!","Đã tối ưu mạng!")
                        Button(onClick={vm.showToast(msgs[i])},colors=ButtonDefaults.buttonColors(containerColor=C_CARD),contentPadding=PaddingValues(8.dp),border=BorderStroke(1.dp,C_BORDER),modifier=Modifier.weight(1f).aspectRatio(0.9f),shape=RoundedCornerShape(14.dp)) {
                            Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(4.dp)) {
                                Icon(icon,null,tint=C_GREEN,modifier=Modifier.size(20.dp))
                                Text(lbl,color=C_TEXT2,fontSize=7.sp,letterSpacing=0.5.sp,textAlign=TextAlign.Center)
                            }
                        }
                    }
            }
        }
    }
}

// 
// FEATURES TAB
// 
@Composable
fun FeaturesTab(vm: MainViewModel, tier: KeyTier) {
    val features by vm.features.collectAsState()
    val ctx = LocalContext.current
    val free = features.filter { it.tier == KeyTier.FREE }
    val vip  = features.filter { it.tier == KeyTier.VIP }

    LazyColumn(contentPadding=PaddingValues(16.dp,12.dp,16.dp,16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        item {
            Column(Modifier.padding(bottom=4.dp)) {
                Text("FEATURES",style=TextStyle(fontSize=20.sp,fontWeight=FontWeight.Bold,brush=Brush.horizontalGradient(listOf(C_CYAN,C_PINK)),letterSpacing=4.sp))
                Text("Tính năng tối ưu hóa",color=C_TEXT3,fontSize=11.sp,letterSpacing=2.sp)
            }
        }
        // FREE
        item {
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Box(Modifier.clip(RoundedCornerShape(4.dp)).background(C_CYAN.copy(0.08f)).border(1.dp,C_BORDER2,RoundedCornerShape(4.dp)).padding(horizontal=8.dp,vertical=3.dp)) {
                    Text("FREE",color=C_CYAN,fontSize=9.sp,letterSpacing=1.sp,fontWeight=FontWeight.Bold)
                }
                Text("Basic Optimization",color=C_TEXT2,fontSize=10.sp)
            }
        }
        items(free) { f -> FeatureCard(f, canUse=true, onToggle={ vm.toggleFeature(ctx,f.id) }) }
        // VIP
        item { Spacer(Modifier.height(4.dp)) }
        item {
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Box(Modifier.clip(RoundedCornerShape(4.dp)).background(Brush.horizontalGradient(listOf(C_YELLOW.copy(0.12f),Color(0xFFFF8C00).copy(0.12f)))).border(1.dp,C_YELLOW.copy(0.35f),RoundedCornerShape(4.dp)).padding(horizontal=8.dp,vertical=3.dp)) {
                    Text("VIP",color=C_YELLOW,fontSize=9.sp,letterSpacing=1.sp,fontWeight=FontWeight.Bold)
                }
                Text("Advanced Features",color=C_TEXT2,fontSize=10.sp)
                Spacer(Modifier.weight(1f))
                if(tier!=KeyTier.VIP) {
                    Box(Modifier.clip(RoundedCornerShape(6.dp)).background(Brush.horizontalGradient(listOf(C_PINK,C_PINK2))).padding(horizontal=12.dp,vertical=4.dp).clickable{vm.showToast("Mua key VIP tu admin!")}) {
                        Text("UPGRADE",color=Color.White,fontSize=8.sp,letterSpacing=2.sp,fontWeight=FontWeight.Bold)
                    }
                }
            }
        }
        items(vip) { f -> FeatureCard(f, canUse=tier==KeyTier.VIP, onToggle={ vm.toggleFeature(ctx,f.id) }) }
    }
}

@Composable
fun FeatureCard(f: FeatureData, canUse: Boolean, onToggle: () -> Unit) {
    val borderA by animateFloatAsState(if(f.enabled) 0.5f else 0.1f,tween(300),label="b")
    val scale   by animateFloatAsState(if(f.loading) 0.97f else 1f,spring(stiffness=Spring.StiffnessHigh),label="s")
    val inf = rememberInfiniteTransition(label="fp")
    val pulseA by inf.animateFloat(0.3f,1f,infiniteRepeatable(tween(800,easing=EaseInOutSine),RepeatMode.Reverse),label="pa")

    Card(Modifier.fillMaxWidth().graphicsLayer(scaleX=scale,scaleY=scale).alpha(if(!canUse) 0.45f else 1f),
        shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=C_CARD),border=BorderStroke(1.dp,f.accent.copy(borderA))) {
        Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(if(f.enabled) f.accent.copy(0.18f) else C_CARD2),contentAlignment=Alignment.Center) {
                if(f.loading) CircularProgressIndicator(Modifier.size(22.dp),color=f.accent,strokeWidth=2.dp)
                else Icon(f.icon,null,tint=if(f.enabled) f.accent else C_TEXT3,modifier=Modifier.size(24.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(f.title,color=C_TEXT,fontSize=13.sp,fontWeight=FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                Text(f.desc,color=C_TEXT3,fontSize=11.sp,lineHeight=15.sp)
                if(f.enabled&&!f.loading) {
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                        Box(Modifier.size(6.dp).background(f.accent.copy(pulseA),CircleShape))
                        Text("ĐANG CHẠY",color=f.accent,fontSize=8.sp,fontWeight=FontWeight.ExtraBold,letterSpacing=0.8.sp)
                    }
                }
            }
            Switch(checked=f.enabled,onCheckedChange={if(!f.loading&&canUse) onToggle()},enabled=!f.loading&&canUse,
                colors=SwitchDefaults.colors(checkedThumbColor=Color.White,checkedTrackColor=f.accent,uncheckedThumbColor=C_TEXT3,uncheckedTrackColor=C_CARD2))
        }
    }
}

// 
// STATS TAB
// 
@Composable
fun StatsTab(vm: MainViewModel) {
    val fps by vm.fps.collectAsState(); val cpu by vm.cpu.collectAsState()
    val ram by vm.ram.collectAsState(); val temp by vm.temp.collectAsState()
    val fpsH by vm.fpsHist.collectAsState(); val cpuH by vm.cpuHist.collectAsState()
    val ramH by vm.ramHist.collectAsState(); val tempH by vm.tempHist.collectAsState()

    LazyColumn(contentPadding=PaddingValues(16.dp,12.dp,16.dp,16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Text("LIVE STATS",style=TextStyle(fontSize=20.sp,fontWeight=FontWeight.Bold,brush=Brush.horizontalGradient(listOf(C_CYAN,C_PINK)),letterSpacing=4.sp))
            Text("Thống kê thời gian thực",color=C_TEXT3,fontSize=11.sp,letterSpacing=2.sp)
        }
        item {
            LazyVerticalGrid(GridCells.Fixed(2),Modifier.height(440.dp),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalArrangement=Arrangement.spacedBy(10.dp),userScrollEnabled=false) {
                items(listOf(
                    listOf("FPS Counter",fps,fpsH,C_GREEN,""),
                    listOf("CPU Usage",cpu,cpuH,C_YELLOW,"%"),
                    listOf("RAM Usage",ram,ramH,C_CYAN,"%"),
                    listOf("Temperature",temp,tempH,C_RED,"°"),
                )) { (lbl,v,hist,c,sfx) ->
                    @Suppress("UNCHECKED_CAST")
                    val col=c as Color; val h=hist as List<Int>; val vi=v as Int; val suffix=sfx as String
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=C_CARD),border=BorderStroke(1.dp,C_BORDER)) {
                        Column(Modifier.padding(12.dp)) {
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                                Text(lbl as String,color=C_TEXT3,fontSize=9.sp,letterSpacing=1.sp)
                                Text("$vi$suffix",color=col,fontSize=18.sp,fontWeight=FontWeight.Bold)
                            }
                            Spacer(Modifier.height(8.dp))
                            // Graph bars
                            Row(Modifier.fillMaxWidth().height(40.dp),horizontalArrangement=Arrangement.spacedBy(2.dp),verticalAlignment=Alignment.Bottom) {
                                val maxV = if(h.isEmpty()) 1 else h.max().coerceAtLeast(1)
                                if(h.isEmpty()) repeat(10){Box(Modifier.weight(1f).fillMaxHeight(0.1f).clip(RoundedCornerShape(topStart=2.dp,topEnd=2.dp)).background(col.copy(0.2f)))}
                                else h.forEach { hv -> Box(Modifier.weight(1f).fillMaxHeight((hv.toFloat()/maxV).coerceIn(0.05f,1f)).clip(RoundedCornerShape(topStart=2.dp,topEnd=2.dp)).background(col.copy(0.65f))) }
                            }
                            Spacer(Modifier.height(6.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                                val mn=if(h.isEmpty())"--" else "${h.min()}$suffix"
                                val av=if(h.isEmpty())"--" else "${h.average().toInt()}$suffix"
                                val mx=if(h.isEmpty())"--" else "${h.max()}$suffix"
                                Text("Min: $mn",color=C_TEXT3,fontSize=9.sp); Text("Avg: $av",color=C_TEXT3,fontSize=9.sp); Text("Max: $mx",color=C_TEXT3,fontSize=9.sp)
                            }
                        }
                    }
                }
            }
        }
        item { Text("Network / Mạng",color=C_TEXT2,fontSize=10.sp,letterSpacing=2.sp,fontWeight=FontWeight.SemiBold) }
        item {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                listOf("Download" to "↓", "Upload" to "↑", "Ping" to "⟳").forEach { (lbl,icon) ->
                    Card(Modifier.weight(1f),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=C_CARD),border=BorderStroke(1.dp,C_BORDER)) {
                        Column(Modifier.padding(14.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                            Text(icon,color=C_GREEN,fontSize=20.sp)
                            Spacer(Modifier.height(4.dp))
                            Text("-- ${if(lbl=="Ping") "ms" else "MB/s"}",color=C_GREEN,fontSize=12.sp,fontWeight=FontWeight.Bold)
                            Text(lbl,color=C_TEXT3,fontSize=9.sp,letterSpacing=1.sp)
                        }
                    }
                }
            }
        }
    }
}

// 
// INFO TAB
// 
@Composable
fun InfoTab(ctx: Context, vm: MainViewModel) {
    val tier by vm.tier.collectAsState()
    val inf = rememberInfiniteTransition(label="info")
    val ringRot by inf.animateFloat(0f,360f,infiniteRepeatable(tween(12000,easing=LinearEasing)),label="rr")
    val dotP    by inf.animateFloat(0f,1f,infiniteRepeatable(tween(2000,easing=EaseInOutSine),RepeatMode.Reverse),label="dp")
    val borderH by inf.animateFloat(0f,360f,infiniteRepeatable(tween(4000,easing=LinearEasing)),label="bh")

    LazyColumn(contentPadding=PaddingValues(bottom=24.dp)) {
        // Hero
        item {
            Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(C_GREEN.copy(0.06f),Color.Transparent))).padding(top=28.dp,bottom=16.dp),contentAlignment=Alignment.Center) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Box(Modifier.clip(RoundedCornerShape(4.dp)).background(C_GREEN.copy(0.06f)).border(1.dp,C_GREEN.copy(0.3f),RoundedCornerShape(4.dp)).padding(horizontal=12.dp,vertical=3.dp)) {
                        Text("DEVELOPER INFO",color=C_GREEN,fontSize=9.sp,letterSpacing=3.sp,fontWeight=FontWeight.Bold)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("OWNER&ADMIN",color=C_TEXT,fontSize=22.sp,fontWeight=FontWeight.Black,letterSpacing=3.sp)
                    Text(buildAnnotatedString{withStyle(SpanStyle(brush=Brush.horizontalGradient(listOf(C_GREEN,C_CYAN)))){append("Nguyen Duy Anh")}},fontSize=22.sp,fontWeight=FontWeight.Black,letterSpacing=3.sp)
                }
            }
        }

        // Avatar card
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal=16.dp),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=C_CARD),border=BorderStroke(1.dp,C_GREEN.copy(0.15f))) {
                Column(Modifier.fillMaxWidth().padding(28.dp,28.dp,28.dp,24.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                    Box(Modifier.size(100.dp),contentAlignment=Alignment.Center) {
                        Canvas(Modifier.size(160.dp)) {
                            val cx=size.width/2;val cy=size.height/2
                            listOf(80.dp.toPx() to 0.12f,65.dp.toPx() to 0.08f).forEach{(r,a)->drawArc(C_GREEN.copy(a),ringRot,360f,false,topLeft=Offset(cx-r,cy-r),size=Size(r*2,r*2),style=Stroke(1f))}
                        }
                        Box(Modifier.size(100.dp).background(Brush.sweepGradient(listOf(C_GREEN,C_CYAN,C_PURPLE,C_GREEN)),CircleShape).padding(3.dp)) {
                            Box(Modifier.fillMaxSize().background(C_BG,CircleShape),contentAlignment=Alignment.Center) {
                            val avatarBmp = remember {
                                try { ctx.assets.open("icons/avatar.png").use { android.graphics.BitmapFactory.decodeStream(it) } } catch (_: Exception) { null }
                            }
                            if (avatarBmp != null) {
                                Image(avatarBmp.asImageBitmap(), null, modifier = Modifier.fillMaxSize().clip(CircleShape), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                            } else { Text("👾", fontSize=38.sp) }
                        }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Nguyen Duy Anh",color=C_TEXT,fontSize=20.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(8.dp).background(C_GREEN.copy(0.5f+dotP*0.5f),CircleShape))
                        Text("ONLINE · ACTIVE",color=C_GREEN.copy(0.75f),fontSize=10.sp,letterSpacing=1.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(Brush.horizontalGradient(listOf(C_GREEN.copy(0.15f),C_CYAN.copy(0.1f)))).border(1.dp,C_GREEN.copy(0.25f),RoundedCornerShape(20.dp)).padding(horizontal=16.dp,vertical=5.dp)) {
                        Text("⚡ DEVELOPER · TWEAK NOVA TECH",color=C_GREEN,fontSize=9.sp,letterSpacing=1.sp,fontWeight=FontWeight.Bold)
                    }
                }
            }
        }

        // Stats row (tier info)
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=12.dp).clip(RoundedCornerShape(14.dp)).background(C_GREEN.copy(0.04f)).border(1.dp,C_GREEN.copy(0.1f),RoundedCornerShape(14.dp)).padding(14.dp,0.dp),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically) {
                Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.padding(vertical=14.dp)) {
                    Text(when(tier){KeyTier.VIP->"VIP";KeyTier.FREE->"FREE";else->"NONE"},color=C_GREEN,fontSize=18.sp,fontWeight=FontWeight.Bold)
                    Text("TIER",color=C_TEXT3,fontSize=9.sp,letterSpacing=1.sp,modifier=Modifier.padding(top=2.dp))
                }
                Box(Modifier.width(1.dp).height(36.dp).background(C_GREEN.copy(0.12f)))
                Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.padding(vertical=14.dp)) {
                    Text(if(tier==KeyTier.NONE) "--" else "ACTIVE",color=C_GREEN,fontSize=18.sp,fontWeight=FontWeight.Bold)
                    Text("STATUS",color=C_TEXT3,fontSize=9.sp,letterSpacing=1.sp,modifier=Modifier.padding(top=2.dp))
                }
                Box(Modifier.width(1.dp).height(36.dp).background(C_GREEN.copy(0.12f)))
                Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.padding(vertical=14.dp)) {
                    Text("v2.0",color=C_GREEN,fontSize=18.sp,fontWeight=FontWeight.Bold)
                    Text("BUILD",color=C_TEXT3,fontSize=9.sp,letterSpacing=1.sp,modifier=Modifier.padding(top=2.dp))
                }
            }
        }

        item { Text("── LIEN HE ──",color=C_TEXT3,fontSize=9.sp,letterSpacing=3.sp,modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=4.dp),textAlign=TextAlign.Center) }

        // Contact cards - TikTok thay Telegram
        val contacts = listOf(
            listOf("TikTok","@ngdanhchumfile.ffxh","Tiktok me","icons/tiktok.png",Color(0xFFFF0050),Color(0xFFFF0050).copy(0.12f),Color(0xFFFF0050).copy(0.25f),"https://www.tiktok.com/@ngdanhchumfile.ffxh"),
            listOf("Facebook","facebook.com/share/1CuyLPvE3g/","Facebook me","icons/facebook.png",Color(0xFF1877F2),Color(0xFF1877F2).copy(0.12f),Color(0xFF1877F2).copy(0.25f),"https://www.facebook.com/share/1CuyLPvE3g/"),
            listOf("Zalo","0387 438 872","Chat trực tiếp · Mua key","icons/zalo.png",Color(0xFF0068FF),Color(0xFF0068FF).copy(0.12f),Color(0xFF0068FF).copy(0.25f),"https://zalo.me/84392633515"),
        )
        items(contacts) { c ->
            @Suppress("UNCHECKED_CAST")
            val col=c[4] as Color; val bgCol=c[5] as Color; val borCol=c[6] as Color
            Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=5.dp).clickable{try{ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(c[7] as String)))}catch(e:Exception){}},
                shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=bgCol),border=BorderStroke(1.dp,borCol)) {
                Row(Modifier.fillMaxWidth().padding(14.dp,12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(bgCol).border(1.dp,borCol,RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center) {
                        val iconPath = c[3] as String
                        val bmp = remember(iconPath) {
                            try { ctx.assets.open(iconPath).use { BitmapFactory.decodeStream(it) } } catch (_: Exception) { null }
                        }
                        if (bmp != null) {
                            Image(bmp.asImageBitmap(), null, modifier = Modifier.size(32.dp).clip(RoundedCornerShape(6.dp)))
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        Text(c[0] as String,color=C_TEXT,fontSize=13.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp)
                        Text(c[1] as String,color=col,fontSize=11.sp)
                        Text(c[2] as String,color=C_TEXT3,fontSize=10.sp)
                    }
                    Text("›",color=C_TEXT3,fontSize=20.sp)
                }
            }
        }

        // App info + key info
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=8.dp),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=C_CARD),border=BorderStroke(1.dp,C_GREEN.copy(0.1f))) {
                Column(Modifier.padding(16.dp)) {
                    Text("APP INFO",color=C_GREEN,fontSize=10.sp,letterSpacing=2.sp,fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    listOf("Ten app" to "TweakNovaTech","Phien ban" to "v2.0.1","Developer" to "Nguyen Duy Anh","Platform" to "Android","Engine" to "Shell Script").forEach{(k,v)->
                        Row(Modifier.fillMaxWidth().padding(vertical=5.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                            Text(k,color=C_TEXT3,fontSize=10.sp)
                            Text(v,color=C_GREEN,fontSize=10.sp,fontWeight=FontWeight.SemiBold)
                        }
                        Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(0.04f)))
                    }
                }
            }
        }

        // Logout key button
        item {
            Box(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=4.dp),contentAlignment=Alignment.Center) {
                TextButton(onClick={KeyManager.clear(ctx);vm.showToast("Đã xoá key! Khởi động lại app để nhập key mới.");vm.setScreen(AppScreen.KEY)}) {
                    Text("Đổi Key / Đăng xuất",color=C_TEXT3,fontSize=10.sp,letterSpacing=1.sp)
                }
            }
        }
    }
}

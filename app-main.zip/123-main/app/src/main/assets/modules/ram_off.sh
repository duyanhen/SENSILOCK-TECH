# ram OFF
settings delete global cached_apps_freezer

settings delete global activity_manager_constants

settings delete global settings_enable_monitor_phantom_procs

settings delete global sem_enhanced_cpu_responsiveness

settings delete global ram_expand_size_list

settings delete secure speed_mode

setprop persist.sys.purgeable_assets ""

setprop persist.sys.trim_enabled ""

setprop persist.sys.lmk.reportkills ""

setprop persist.sys.lmk.debug ""

setprop persist.device_config.runtime_native.use_app_image_startup_cache ""

setprop dalvik.vm.heapstartsize ""

setprop dalvik.vm.heapgrowthlimit ""

setprop dalvik.vm.heapsize ""

setprop dalvik.vm.heaptargetutilization ""

setprop dalvik.vm.heapminfree ""

setprop dalvik.vm.heapmaxfree ""

setprop ro.lmk.low ""

setprop ro.lmk.medium ""

setprop ro.lmk.critical ""

setprop ro.config.low_ram ""

setprop persist.sys.zram_enabled ""

setprop persist.sys.zram_size ""

setprop persist.sys.fuse.passthrough.enable ""

setprop debug.kill_allocating_task ""

setprop debug.sf.enable_hwc_vds ""

setprop debug.hwui.renderer ""

setprop debug.hwui.disable_vsync ""

setprop debug.hwui.use_hint_manager ""

setprop debug.performance.tuning ""

setprop video.accelerate.hw ""

setprop debug.sf.latch_unsignaled ""

setprop persist.sys.ui.hw ""

setprop persist.sys.use_dithering ""

setprop persist.sys.scrollingcache ""

setprop windowsmgr.max_events_per_sec ""

setprop persist.sys.NV_FPSLIMIT ""

setprop persist.sys.NV_POWERMODE ""

setprop persist.sys.smartpower ""

setprop persist.sys.background_apps_limit ""

setprop persist.sys.fflag.override.settings_enable_monitor_phantom_procs ""

cmd thermalservice override-status reset

cmd power set-adaptive-power-saver-enabled true

cmd power set-fixed-performance-mode-enabled false

cmd netpolicy set restrict-background true
settings delete system touch_prediction_enabled
settings delete system touch_smoothing_enabled
settings delete system touch_raw_mode
settings delete system touch_controller_mode
settings delete system touch_resolution_scale
settings delete system pointer_acceleration_enabled
settings delete system pointer_precision_mode
settings delete system pointer_speed
settings delete system touch_sensitivity
settings delete system touch_sensitivity_mode
settings delete system touch_slop
settings delete system scroll_friction
settings delete system touch_latency
settings delete system touch_sampling_rate
settings delete system touch_report_rate
settings delete global touch_sampling_rate
settings delete global touch_report_rate
settings delete global touch_boost
settings delete global touch_boost_enabled
settings delete global low_latency_touch
settings delete global touch_response_boost
settings delete global fast_input_enabled
settings delete secure tap_duration_threshold
settings delete secure long_press_timeout
settings delete system long_press_timeout
settings delete system pointer_snap_enabled
settings delete system pointer_magnetic_strength
settings delete system touch_snap_radius
settings delete system recoil_compensation_enabled
settings delete system aim_assist_strength
settings delete system head_tracking_enabled
settings delete system touch_jitter_filter
settings delete system touch_noise_threshold
cmd device_config delete touchscreen input_drag_min_switch_speed
settings delete system ping_optimizer
settings delete system target_ping
settings delete system packet_loss_reduction
settings delete system network_buffer
settings delete system wifi_5ghz_preferred
settings delete system mobile_data_optimized
settings delete system prefer_5g
settings delete system use_custom_dns
settings delete system primary_dns
settings delete system secondary_dns
settings delete system dns_over_https
settings delete system tcp_fastopen
settings delete system prioritize_game_packets
settings delete system congestion_control
settings delete system qos_enabled
settings delete global zram_enabled
settings delete global zram_compression_algorithm
settings delete global zram_compression_level
settings delete global vm_swappiness
settings delete global low_memory_killer_enable
settings delete global trim_cache_on_low_mem
settings delete global max_cached_processes
settings delete global max_background_processes
settings delete global gaming_memory_constants
settings delete global app_process_constants
device_config delete activity_manager max_cached_processes
device_config delete activity_manager max_phantom_processes
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0
settings delete global disable_window_animation
settings delete global force_all_apps_standby
settings delete global force_background_check
settings delete global disable_auto_sync
settings delete global wifi_scan_always_enabled
settings delete global ble_scan_always_enabled
settings delete global adaptive_battery_management
settings delete global battery_saver_enabled
settings delete global disable_battery_limit
settings delete global fast_charge_enabled
cmd deviceidle disable
cmd appops set com.google.android.gms RUN_IN_BACKGROUND default
cmd appops set com.google.android.gms RUN_ANY_IN_BACKGROUND default
cmd appops set com.google.android.gms START_FOREGROUND default
settings delete global dropbox:dumpsys:procstats
settings delete global dropbox:dumpsys:usagestats
# ==========================================
# 1. RESET SETTINGS (SECURE, GLOBAL, SYSTEM)
# ==========================================
settings delete secure gb_boosting
settings delete secure vtb_boosting

settings delete global miui_cpu_model
settings delete global miui_power_save
settings delete global miui_thermal_policy
settings delete global hwui.disable_vsync
settings delete global force_hw_ui
settings delete global persist.sampling_profiler
settings delete global persist.sys.pugerable_assets
settings delete global touch.pressure.scale

settings delete system persist.sys.scrollingcache
settings delete system debug.cpurend.vsync
settings delete system debug.gpurend.vsync

# Reset các cài đặt PERF_RES (Mediatek/FPSGO)
settings delete global PERF_RES_FPS_FPSGO_LLF_TH
settings delete global PERF_RES_FPS_FPSGO_LLF_POLICY
settings delete global PERF_RES_FPS_FPSGO_LLF_LIGHT_LOADING_POLICY
settings delete global PERF_RES_FPS_FBT_RESCUE_F
settings delete global PERF_RES_FPS_FBT_QR_T2WNT_Y_P
settings delete global PERF_RES_FPS_FBT_QR_T2WNT_Y_N
settings delete global PERF_RES_FPS_FBT_GCC_ENQ_BOUND_THRS
settings delete global PERF_RES_FPS_FBT_GCC_DEQ_BOUND_THRS
settings delete global PERF_RES_FPS_FBT_GCC_DEQ_BOUND_QUOTA
settings delete global PERF_RES_FPS_FBT_GCC_DOWN_QUOTA_PCT
settings delete global PERF_RES_FPS_FPSGO_IDLEPREFER
settings delete global PERF_RES_FPS_FPSGO_SPID
settings delete global PERF_RES_FPS_GBE1_ENABLE
settings delete global PERF_RES_FPS_GBE2_ENABLE
settings delete global PERF_RES_FPS_GBE2_TIMER2_MS1
settings delete global PERF_RES_FPS_GBE2_MAX_BOOST_CNT
settings delete global PERF_RES_FPS_GBE2_TIMER1_MS
settings delete global PERF_RES_FPS_GBE_POLICY_MASK
settings delete global PERF_RES_FPS_FBT_CEILING_ENABLE
settings delete global PERF_RES_GPU_GED_MARGIN_MODE
settings delete global PERF_RES_GPU_FREQ_MAX
settings delete global PERF_RES_FPS_FPSGO_BOOST_LR
settings delete global PERF_RES_FPS_FBT_ULTRA_RESCUE
settings delete global PERF_RES_FPS_FBT_RESCUE_SECOND_GROUP
settings delete global PERF_RES_FPS_FBT_RESCUE_SECOND_TIME
settings delete global PERF_RES_FPS_FBT_RESCUE_SECOND_ENABLE
settings delete global PERF_RES_FPS_FBT_GCC_FPS_MARGIN

# Reset tối ưu cảm ứng
settings delete global touch_boost
settings delete global touch_boost_enabled
settings delete global low_latency_touch
settings delete global touch_response_boost
settings delete global fast_input_enabled

# ==========================================
# 2. RESET CMD (LỆNH HỆ THỐNG)
# ==========================================
# Khôi phục dịch vụ tản nhiệt và chế độ hiệu năng
cmd thermalservice reset
cmd power set-fixed-performance-mode-enabled false

# Xóa overlay của game (áp dụng nếu biến $pkg vẫn đang được lưu trong script)
cmd device_config delete game_overlay "$pkg"

# ==========================================
# 3. RESET SETPROP (THUỘC TÍNH DEBUG)
# ==========================================
setprop debug.hwui.force_msaa ""
setprop debug.hwui.force_fxaa ""
setprop debug.hwui.force_smaa ""
setprop debug.hwui.force_txaa ""
setprop debug.hwui.force_csaa ""
setprop debug.hwui.force_dlss ""

setprop debug.egl.force_msaa ""
setprop debug.egl.force_fxaa ""
setprop debug.egl.force_smaa ""
setprop debug.egl.force_txaa ""
setprop debug.egl.force_csaa ""
setprop debug.egl.force_dlss ""
setprop debug.egl.force_dmsaa ""

setprop debug.OVRPlugin.systemDisplayFrequency ""
setprop debug.OVRManager.cpuLevel ""
setprop debug.OVRManager.gpuLevel ""

setprop debug.sf.early_phase_offset_ns ""
setprop debug.sf.enable_gl_backpressure ""
setprop debug.sf.multithreaded_present ""
setprop debug.sf.enable_hwc_vds ""
setprop debug.sf.latch_unsignaled ""
setprop debug.sf.disable_backpressure ""

setprop debug.cpurend.vsync ""

setprop debug.hwui.use_buffer_age ""
setprop debug.hwui.force_gpu ""
setprop debug.hwui.use_fast_path ""
setprop debug.hwui.enable_threaded_render ""
setprop debug.hwui.optimize_rendering ""
setprop debug.hwui.enable_partial_render ""
setprop debug.hwui.texture_pool ""
setprop debug.hwui.max_texture_size ""
setprop debug.hwui.disabledither ""

setprop debug.performance.tuning ""
setprop debug.texture.scale ""
setprop debug.performance_schema ""
setprop debug.performance_schema_max_memory_classes ""
setprop debug.performance_schema_max_socket_classes ""

setprop debug.composition.type ""
setprop debug.composition.type2 ""
setprop debug.gr.swapinterval ""
setprop debug.systemuicompilerfilter ""
setprop debug.rs.precision ""

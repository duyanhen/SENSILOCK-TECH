# General Game Driver & Performance Modes
settings put global game_driver_all_apps 1
settings put global game_driver_opt_out_apps ""
settings put global game_driver_prerelease_allowlist ""
settings put global hwui_force_gpu 1
settings put global force_hw_ui 1
settings put global disable_vsync 1
settings put global persist.sys.NV_CUSTOM_GAME_FPS 120
settings put global sustained_performance_mode_enabled 1

# CPU / GPU & Thermal Limits (System-wide)
cmd power set-fixed-performance-mode-enabled true
cmd power set-adaptive-power-saver-enabled false
cmd power set-mode 0
cmd thermalservice override-status 0
pm disable-user com.miui.powerkeeper
settings put system POWER_PERFORMANCE_MODE_OPEN 1
settings put system high_performance_mode_on 1
settings put secure speed_mode_enable 1
settings put global miui_performance_mode 1
settings put global performance_profile 1
settings put system sem_performance_mode 4
settings put system sem_turbo_mode 1
settings put global cpu_gpu_constants "cpu_boost_threshold=100, gpu_boost_threshold=100, cpu_max_freq=3000000, gpu_max_freq=1000000000, cpu_min_freq=300000, gpu_min_freq=300000000, cpu_affinity=0,1,2,3,4,5,6,7, gpu_affinity=0,1,2,3"
settings put global dynamic_frequency_scaling_constants "cpu_scaling_max=3000000, gpu_scaling_max=700000000, cpu_scaling_min=300000, gpu_scaling_min=200000000, cpu_interactive_target_load=100, gpu_interactive_target_load=100"
settings put global gaming_power_constants "gaming_performance_mode=true, max_cpu_performance=100, max_gpu_performance=100, cpu_power_saving_mode=false, gpu_power_saving_mode=false, disable_background_services=true, aggressive_power_save_mode=false, enable_high_performance_graphics=true, disable_vsync=true, disable_surface_view=false, disable_fullscreen=false, enable_cpu_boost=true, enable_gpu_boost=true, disable_power_save=true"
settings put system cpu_boost_input_boost_ms 88
settings put system cpu_boost_powerkey_input_boost_ms 400
settings put system cpu_boost_input_boost_enabled 1
settings put system cpu_set_effective_cpus 7
settings put system cpu_set_foreground_cpus 6
settings put system cpu_set_top-app_cpus 7

# FPS & Refresh Rate (System-wide 120Hz/FPS)
settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120
settings put system user_refresh_rate 120
settings put global force_high_refresh_rate 1
settings put global adaptive_refresh_rate_enabled 0
settings put system adaptive_refresh_rate 0
settings put system exact_refresh_rate_enabled 1
settings put system display_frequency_forced 1
settings put system fps_limit 120
setprop debug.sf.frame_rate_multiple_threshold 0
setprop debug.sf.scroll_boost_refreshrate 120
setprop debug.sf.touch_boost_refreshrate 120
setprop debug.hwui.fpslimit 120
setprop debug.hwui.fps_limit 120
setprop debug.refresh_rate.min_fps 120
setprop debug.refresh_rate.max_fps 120
setprop debug.refresh_rate.peak_fps 120

# HWUI & SurfaceFlinger Optimization (Graphics Acceleration)
setprop debug.hwui.force_gpu 1
setprop debug.hwui.use_fast_path 1
setprop debug.hwui.enable_threaded_render 1
setprop debug.hwui.optimize_rendering 1
setprop debug.hwui.enable_partial_render 1
setprop debug.hwui.disable_vsync true
setprop debug.sf.multithreaded_present true
setprop debug.sf.enable_hwc_vds 1
setprop debug.cpurend.vsync false
setprop debug.performance.tuning 1
setprop debug.egl.hw 1
setprop debug.sf.hw 1
cmd device_config put system display_refresh_rate 120
settings put secure user_refresh_rate 120
settings put secure miui_refresh_rate 120
settings put system min_frame_rate 120
settings put system max_frame_rate 120
settings put system tran_refresh_mode 120
settings put system last_tran_refresh_mode_in_refresh_setting 120
settings put global min_fps 120
settings put global max_fps 120
settings put system tran_need_recovery_refresh_mode 120
settings put system display_min_refresh_rate 120 
settings put system min_refresh_rate 120
settings put system max_refresh_rate 120
settings put system peak_refresh_rate 120
settings put secure refresh_rate_mode
 120
settings put system user_refresh_rate 120
settings put system thermal_limit_refresh_rate 120
settings put system NV_FPSLIMIT 120
settings put system fps.limit.is.now locked
# Cài đặt khóa FPS mới (120Hz)
settings put system user_refresh_rate 120
settings put system fps_limit 120
settings put system max_refresh_rate_for_ui 120
settings put system hwui_refresh_rate
 120
settings put system display_refresh_rate 120
settings put system max_refresh_rate_for_gaming 1
setprop debug.egl.force_fxaa false 
setprop debug.egl.force_taa false 
setprop debug.egl.force_msaa false 
setprop debug.egl.force_ssaa false 
setprop debug.egl.force_smaa false 
setprop debug.egl.force_mlaa false 
setprop debug.egl.force_txaa false 
setprop debug.egl.force_csaa false
setprop debug.cpurend.vsync false 
setprop debug.gpurend.vsync false 
setprop debug.sf.showupdates 0 
setprop debug.sf.showcpu 0 
setprop debug.sf.showbackground 0 
setprop debug.sf.showfps 0 
setprop debug.egl.swapinterval -60 
setprop debug.egl.hw 1 
setprop debug.egl.profiler 1 
setprop debug.gr.swapinterval 0 
setprop debug.gr.numframebuffers 3 
setprop debug.performance.tuning 1 
setprop debug.sf.disable_backpressure 1 
setprop debug.sf.latch_unsignaled 1 
setprop debug.sf.enable_hwc_vds 1 
setprop debug.sf.early_phase_offset_ns 500000 
setprop debug.sf.early_app_phase_offset_ns 500000 
setprop debug.sf.early_gl_phase_offset_ns 3000000 
setprop debug.sf.early_gl_app_phase_offset_ns 15000000 
setprop debug.sf.high_fps_early_phase_offset_ns 6100000 
setprop debug.sf.high_fps_early_gl_phase_offset_ns 650000 
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000 
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000 
setprop debug.sf.hw 1 
setprop debug.thermal.enable false 
setprop debug.thermal.disable true 
setprop debug.OVRManager.cpuLevel 2 
setprop debug.OVRManager.gpuLevel 2 
setprop debug.hwui.target_cpu_time_percent 100 
setprop debug.hwui.target_gpu_time_percent 100 
setprop debug.cpuprio 7 
setprop debug.gpuprio 7 
setprop debug.composition.type gpu 
setprop debug.rs.default-CPU-driver 1 
setprop debug.rs.max-threads 8 
setprop debug.rs.min-threads 8 
setprop debug.hwui.render_dirty_regions false 
setprop debug.hw2d.force 1 
setprop debug.hw3d.force 1 
setprop debug.power_management_mode pref_max 
setprop debug.max_freq_limit 6830 
setprop debug.min_freq_limit 6830 
setprop debug.gpu.cooling.callback_freq_limit false 
setprop debug.cpu.cooling.callback_freq_limit false 
setprop debug.renderthread.reduceopstasksplitting true 
setprop debug.dev.ssrm.turbo true 
setprop debug.vendor.dfps.enable false 
setprop debug.vendor.smart_dfps.enable false 
setprop debug.hwui.disable_vsync true 
setprop debug.hwui.render_dirty_regions false 
setprop debug.persist.dev.pm.dyn_samplingrate 1 
setprop debug.egl.buffcount 4 
setprop debug.debug.enabletr 1 
setprop debug.hwui.renderer skiagl 
setprop debug.renderengine.backend skiaglthreaded 
setprop debug.hwui.use_gpu_pixel_buffers true 
setprop debug.hwui.skia_atrace_enabled false 
setprop debug.sf.disable_client_composition_cache 1 
setprop debug.persist.service.lgospd.enable 0 
setprop debug.persist.service.pcsync.enable 0 
setprop debug.surface_flinger.max_frame_buffer_acquired_buffers 3 
setprop debug.surface_flinger.running_without_sync_framework true 
setprop debug.surface_flinger.force_hwc_copy_for_virtual_displays true 
setprop debug.surface_flinger.has_HDR_display true 
setprop debug.surface_flinger.has_wide_color_display true 
setprop debug.surface_flinger.max_virtual_display_dimension 4096 
setprop debug.surface_flinger.protected_contents true 
setprop debug.persist.cpu.gov.performance performance 
setprop debug.persist.gpu.gov.performance performance 
setprop debug.scroll_friction 10 
setprop debug.hwui.skip_empty_damage true 
setprop debug.systemuicompilerfilter speed 
setprop debug.gpu.scheduler_pre.emption 1 
setprop debug.disable_sched_boost true 
setprop debug.persist.sys.NV_FPSLIMIT 60 
setprop debug.persist.sys.NV_POWERMODE 1 
setprop debug.persist.sys.NV_PROFVER 15 
setprop debug.persist.sys.NV_STEREOCTRL 0 
setprop debug.persist.sys.NV_STEREOSEPCHG 0 
setprop debug.persist.sys.NV_STEREOSEP 20 
setprop debug.persist.sys.purgeable_assets 1 
setprop debug.persist.sys.dalvik.hyperthreading true 
setprop debug.persist.sys.dalvik.multithread true 
setprop debug.persist.sys.composition.type gpu 
setprop debug.persist.sys.ui.hw 1 
setprop debug.hwui.fps_divisor -1 
setprop debug.hwui.use_hint_manager true
setprop debug.egl.force_msaa false
setprop debug.egl.force_fxaa false
setprop debug.egl.force_taa false
setprop debug.egl.force_smaa false
setprop debug.egl.force_txaa false
setprop debug.cpurend.vsync false
setprop debug.composition.type c2d
setprop debug.hwui.renderer skiagl
setprop debug.gr.swapinterval 120
setprop debug.gr.numframebuffers 3
setprop debug.sf.profile_maxframes 120
setprop debug.egl.swapinterval 1
setprop debug.sf.showfps 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.shoupdates 0
setprop debug.egl.buffcount 4
setprop debug.egl.force_msaa 1
setprop debug.kill_allocating_task 0
setprop debug.overlayui.enable 1
setprop debug.hwui.texture_cache_size 0
setprop debug.force_rtl false
setprop debug.sf.swaprect 1
setprop debug.hw2d.force true
setprop debug.hw3d.force true
setprop debug.hwui.render_quality high
setprop debug.egl.log_config 0
setprop debug.sf.vsync_sf_event_phase_offset_ns 0
setprop debug.systemuicompilerfilter speed
setprop debug.hwui.render_priority 1
setprop debug.hwui.print_config 0
setprop debug.hwui.show_dirty_regions 0
setprop debug.hwui.render_dirty_regions 0
setprop debug.hwui.show_non_rect_clip highlight
setprop debug.layout false
setprop debug.orientation.log false
setprop debug.rs.qcom.disable_expand 1
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.enable_advanced_sf_phase_offset 1
setprop debug.sf.enable_gl_backpressure 1
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.set_idle_timer_ms 30
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.earlyGl.app.duration 16600000;setprop debug.sf.earlyGl.sf.duration 16600000;setprop debug.sf.frame_rate_multiple_threshold 120;setprop debug.sf.hwc_hdcp_via_neg_vsync 1;setprop debug.sf.hwc_hotplug_error_via_neg_vsync 1;setprop debug.sf.late.app.duration 16600000;setprop debug.sf.late.sf.duration 10500000;setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.treat_170m_as_sRGB 1
setprop debug.sf.gpu_freq_index 7
setprop debug.sf.cpu_freq_index 7
setprop debug.sf.memory_freq_index 7
setprop debug.graphics.gpu.profiler.support true
setprop debug.systemuicompilerfilter speed
setprop debug.javafx.animation.fullspeed true
setprop debug.performance.client 1
setprop debug.performance_schema_digests_size 66000000
setprop debug.sf.enable_frame_rate_boost true
setprop debug.performance.cap uncapped
setprop debug.performance.disturb false
setprop debug.performance_schema_digests_size 9950000
setprop debug.performance_schema 1
setprop debug.perfomance.tuning 1
setprop debug.performance_schema_max_memory_classes 320
setprop debug.performance_schema_max_socket_classes 10
setprop debug.atrace.tags.enableflags 0;setprop debug.composition.type c2d;setprop debug.cpurend.vsync false;setprop debug.cpurend.vsync false;setprop debug.doze.component 0;setprop debug.egl.buffcount 4;setprop debug.egl.hw 1;setprop debug.egl.swapinterval -60;setprop debug.enabletr true;setprop debug.gr.numframebuffers 3;setprop debug.gr.numframebuffers 3;setprop debug.hwui.render_dirty_regions false;setprop debug.kill_allocating_task 0;setprop debug.kill_allocating_task 0;setprop debug.overlayui.enable 1;setprop debug.performance.tuning 1;setprop debug.qc.hardware true;setprop debug.qctwa.preservebuf 1;setprop debug.qctwa.statusbar 1;setprop debug.sf.hw 1;setprop debug.sf.hw 1;setprop debug.sf.showcpu 0
setprop debug.hwui.renderer skiagl
setprop debug.redroid.fps 120
setprop debug.gr.swapinterval -1 
setprop debug.hwui.disabledither false 
setprop debug.disable.hwacc 0 
setprop debug.disable_sched_boost true 
setprop debug.javafx.animation.fullspeed true 
setprop debug.rs.default-CPU-driver 1 
setprop debug.MB.inner.running 24
setprop debug.MB.running 72
setprop debug.qsg_renderer 1
setprop debug.hwui.render_dirty_regions false
setprop debug.hwc.bq_count 3 
setprop debug.MB.running 1
setprop debug.systemuicompilerfilter speed
setprop debug.egl.force_msaa false
setprop debug.egl.force_fxaa false
setprop debug.egl.force_taa false 
setprop debug.egl.force_ssaa false
setprop debug.egl.force_smaa false
setprop debug.egl.swapinterval 1
setprop debug.mdpcomp.mixedmode.disable false
setprop debug.forceAutoTextureCompression 1
setprop debug.cpurend.vsync false
setprop debug.gpurend.vsync false
setprop debug.choreographer.skipwarning 12500000
setprop debug.egl.buffcount 4
setprop debug.dev.ssrm.turbo true
setprop debug.enabletr true
setprop debug.rs.default-CPU-buffer 65536
setprop debug.fb.rgb565 1
setprop debug.disable.computedata true
setprop debug.lldb-rpc-server 0
setprop debug.qctwa.preservebuf 1
setprop debug.app.performance_restricted false
setprop debug.mdlogger.Running 0
setprop debug.power.profile high_performance
setprop debug.performance.tuning 1
setprop debug.cpuprio 7 
setprop debug.gpuprio 7 
setprop debug.ioprio 7
setprop debug.performance_schema 1
setprop debug.performance_schema_max_memory_classes 320
setprop debug.gpu.scheduler_pre.emption 1
setprop debug.stagefright.c2inputsurface -1
setprop debug.stagefright.ccodec 4
setprop debug.stagefright.omx_default_rank 512
setprop debug.performance_schema_max_socket_classes 10 
setprop debug.sdm.disable_skip_validate 1
setprop debug.egl.native_scaling true
setprop debug.multicore.processing 1
setprop debug.mediatek.appgamepq_compress 1
setprop debug.mediatek.disp_decompress 1
setprop debug.hwui.target_cpu_time_percent 100
setprop debug.hwui.target_gpu_time_percent 100
setprop debug.hwui.fps_divisor -1
setprop debug.hwui.use_hint_manager 1
setprop debug.hwui.disabledither false
setprop debug.hwui.disable_vsync true
setprop debug.hwui.skip_empty_damage true
setprop debug.hwui.disable_draw_defer true
setprop debug.hwui.use_partial_updates true
setprop debug.hwui.disable_draw_reorder true
setprop debug.hwui.filter_test_overhead true
setprop debug.OVRManager.cpuLevel 1
setprop debug.OVRManager.gpuLevel 1
setprop debug.gralloc.gfx_ubwc_disable false
setprop debug.mdpcomp.mixedmode false
setprop debug.hwc.fbsize XRESxYRES
setprop debug.sdm.support_writeback 1
setprop debug.power_management_mode pref_max
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.high_fps_early_phase_offset_ns 6100000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 650000
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000
setprop debug.sf.showupdates 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.showfps 0
setprop debug.sf.hw 1
settings delete system thermal_limit_refresh_rate
settings put system performance_mode_enable 1
settings put secure refresh_rate_mode 2
settings put secure speed_mode_enable 1
settings put global job_scheduler_constant 1
settings put global cached_apps_freezer 1
settings put global activity_manager_constants max_cached_processes 1024
settings put global low_power 0 
settings put global job_scheduler_constants null 
settings put system thermal_limit_refresh_rate 1 
settings put system thermal_limit_frame_rate 1
settings put global fstrim_mandatory_interval 864000000
settings put global low_power 0
settings put global low_power_sticky 0
settings put global heat_suppression 0
settings put global app_standby_enabled 0
cmd thermalservice override-status 0
cmd power set-fixed-performance-mode-enabled true
setprop debug.compogition.type mdp
setprop debug.fb.rgb565 1
setprop debug.enabletr false
setprop debug.gygtemuicompilerfilter gpeed
setprop debug.rg.precigion rg_fp_full
setprop debug.rg.default-CPU-buffer 262144
setprop debug.javafx.animation.fullgpeed true
setprop debug.javafx.animation.framerate 120
setprop debug.digable.hwacc 0
setprop debug.qctwa.pregervebuf 1
setprop debug.MB.running 72
setprop debug.MB.inner.running 24
setprop debug.app.performance_regtricted false
setprop debug.rg.max-threadg 8
setprop debug.rg.min-threadg 8
setprop debug.gr.numframebuffer 0
setprop debug.power_management_mode pref_max
setprop debug.hwui.renderer Vulkan 
setprop debug.hwui.fps_divisor 1
setprop debug.egl.hw 1
setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.latch_unsignaled 1
setprop debug.renderengine.backend Vulkan
setprop debug.sf.swapinterval -1
setprop debug.egl.swapinterval -1
setprop debug.gr.swapinterval 1
setprop debug.st.high_fps_early_phase_offset_ns 6100000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 9000000
setprop debug.hwui.renderer skiagl
setprop debug.redroid.fps 120
setprop debug.gr.swapinterval -1 
setprop debug.hwui.disabledither false 
setprop debug.disable.hwacc 0 
setprop debug.disable_sched_boost true 
setprop debug.javafx.animation.fullspeed true 
setprop debug.rs.default-CPU-driver 1 
setprop debug.MB.inner.running 24
setprop debug.MB.running 72
setprop debug.qsg_renderer 1
setprop debug.hwui.render_dirty_regions false
setprop debug.hwc.bq_count 3 
setprop debug.MB.running 1
setprop debug.systemuicompilerfilter speed
setprop debug.egl.force_msaa false
setprop debug.egl.force_fxaa false
setprop debug.egl.force_taa false 
setprop debug.egl.force_ssaa false
setprop debug.egl.force_smaa false
setprop debug.egl.swapinterval 1
setprop debug.mdpcomp.mixedmode.disable false
setprop debug.forceAutoTextureCompression 1
setprop debug.cpurend.vsync false
setprop debug.gpurend.vsync false
setprop debug.choreographer.skipwarning 12500000
setprop debug.egl.buffcount 4
setprop debug.dev.ssrm.turbo true
setprop debug.enabletr true
setprop debug.rs.default-CPU-buffer 65536
setprop debug.fb.rgb565 1
setprop debug.disable.computedata true
setprop debug.lldb-rpc-server 0
setprop debug.qctwa.preservebuf 1
setprop debug.app.performance_restricted false
setprop debug.mdlogger.Running 0
setprop debug.power.profile high_performance
setprop debug.performance.tuning 1
setprop debug.cpuprio 7 
setprop debug.gpuprio 7 
setprop debug.ioprio 7
setprop debug.performance_schema 1
setprop debug.performance_schema_max_memory_classes 320
setprop debug.gpu.scheduler_pre.emption 1
setprop debug.stagefright.c2inputsurface -1
setprop debug.stagefright.ccodec 4
setprop debug.stagefright.omx_default_rank 512
setprop debug.performance_schema_max_socket_classes 10 
setprop debug.sdm.disable_skip_validate 1
setprop debug.egl.native_scaling true
setprop debug.multicore.processing 1
setprop debug.mediatek.appgamepq_compress 1
setprop debug.mediatek.disp_decompress 1
setprop debug.hwui.target_cpu_time_percent 100
setprop debug.hwui.target_gpu_time_percent 100
setprop debug.hwui.fps_divisor -1
setprop debug.hwui.use_hint_manager 1
setprop debug.hwui.disabledither false
setprop debug.hwui.disable_vsync true
setprop debug.hwui.skip_empty_damage true
setprop debug.hwui.disable_draw_defer true
setprop debug.hwui.use_partial_updates true
setprop debug.hwui.disable_draw_reorder true
setprop debug.hwui.filter_test_overhead true
setprop debug.OVRManager.cpuLevel 1
setprop debug.OVRManager.gpuLevel 1
setprop debug.gralloc.gfx_ubwc_disable false
setprop debug.mdpcomp.mixedmode false
setprop debug.hwc.fbsize XRESxYRES
setprop debug.sdm.support_writeback 1
setprop debug.power_management_mode pref_max
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.high_fps_early_phase_offset_ns 9000000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 1200000
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000
setprop debug.sf.showupdates 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.showfps 0
setprop debug.sf.hw 1
settings put system peak_refresh_rate 144
settings put system user_refresh_rate 144
settings put system min_refresh_rate 120
settings delete system thermal_limit_refresh_rate
settings put system pointer_speed 7
settings put system performance_mode_enable 1
settings put secure refresh_rate_mode 2
settings put secure speed_mode_enable 1
settings put global job_scheduler_constant 1
settings put global cached_apps_freezer 1
settings put global activity_manager_constants max_cached_processes 1024
settings put global fstrim_mandatory_interval 864000000
settings put global low_power 0
settings put global low_power_sticky 0
settings put global heat_suppression 0
settings put global app_standby_enabled 0
settings put secure game_auto_tempature 0
settings put system rakuten_denwa 0
settings put system send_security_reports 0
settings put global sem_enhanced_cpu_responsiveness 1
settings put global enhanced_processing 2
settings put system multicore_packet_scheduler 1
setprop debug.gr.swapinterval -1
setprop debug.systemuicompilerfilter speed
setprop debug.egl.force_msaa false
setprop debug.egl.force_fxaa false
setprop debug.egl.force_taa false 
setprop debug.egl.force_ssaa false
setprop debug.egl.force_smaa false
setprop debug.egl.swapinterval 1
setprop debug.hw2d.force 1
setprop debug.hw3d.force 1
setprop debug.app.performance_restricted false
setprop debug.performance.tuning 1
setprop debug.stagefright.c2inputsurface -1
setprop debug.stagefright.ccodec 4
setprop debug.stagefright.omx_default_rank 512
setprop debug.multicore.processing 1
setprop debug.hwui.fps_divisor -1
setprop debug.renderengine.backend skiaglthreaded
setprop debug.hwui.renderer skiagl
setprop debug.hwc.fbsize XRESxYRES
setprop debug.sf.set_idle_timer_ms 30
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.high_fps_early_phase_offset_ns 6100000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 650000
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000
setprop debug.sf.showupdates 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.showfps 0
setprop debug.sf.hw 1
settings put global tombstone_enhanced_mode 1
settings put global debug.crash_sys_key_enable 1
settings put global debug.detailed\_tombstones 1
settings put global package_monitor_enable_tombstone 1
settings put global tombstone_sys_error_control 1
settings put global tombstone_anr_show_background 0
settings put global show_tombstone_on_crash 0
settings put global tombstone_sys_pstore 1
setprop debug.tombstonedeadline 999999999999
setprop debug.crash.logcat 0
setprop debug.dumpstate.enable 1
setprop debug.android.tombstone 1
setprop debug.debuggerd 1
setprop debug.dumpstate 1
setprop debug.detailed\_tombstones 1
setprop debug.crash_sys_key_enable 1
settings put global window_animation_scale 0.0
settings put global transition_animation_scale 0.0
settings put global animator_duration_scale 0.0
settings put global updatable_driver_production_opt_in_apps com.dts.freefireth,com.dts.freefiremax
settings put global updatable_driver_production_opt_out_apps 1
settings put global fstrim_mandatory_interval 864000000
settings put global fstrim_trim_interval 864000000
settings put global app_standby_list 0
settings put global always_finish_activities 1
settings put global activity_manager_constants max_cached_processes 3023
settings put system min_refresh_rate 120
settings put system peak_refresh_rate 120
settings put system user_refresh_rate 120
settings delete system thermal_limit_refresh_rate
settings put secure multi_press_timeout 130
settings put secure long_press_timeout 130

settings delete global netstats_enabled
settings delete global wifi_sleep_policy
settings delete global wifi_scan_always_enabled
settings delete global mobile_data_always_on
settings delete global tcp_default_init_rwnd
settings delete global network_watchlist_enabled
settings delete global captive_portal_detection_enabled
settings delete system ping_optimizer
settings delete system target_ping
settings delete system packet_loss_reduction
settings delete system network_buffer
settings delete system prefer_5g
settings delete system use_custom_dns
settings delete system primary_dns
settings delete system secondary_dns
settings delete system dns_over_https
settings delete system tcp_fastopen
cmd device_config delete activity_manager fstrim_mandatory_interval
cmd device_config delete lmkd_native thrashing_limit_critical
cmd device_config delete activity_manager bg_current_drain_auto_restrict_abusive_apps_enabled
cmd device_config delete activity_manager_native_boot use_freezer
cmd device_config delete activity_manager max_cached_processes
cmd device_config delete activity_manager max_phantom_processes
setprop debug.egl.swapinterval ""
setprop debug.gr.swapinterval ""
setprop debug.sf.swapinterval ""
setprop debug.vulkan.swapinterval ""
setprop debug.cpurend.vsync ""
setprop debug.hwui.disable_vsync ""

settings put global background_activity_starts_enabled 1

# Touch, Pointer & Gestures
settings put system touch_prediction_enabled 0
settings put system touch_smoothing_enabled 0
settings put system touch_raw_mode 1
settings put system touch_controller_mode raw
settings put system touch_resolution_scale 2
settings put system pointer_acceleration_enabled 0
settings put system pointer_precision_mode 1
settings put system pointer_speed 7
settings put system touch_sensitivity 1.5
settings put system touch_sensitivity_mode 1
settings put system touch_slop 2
settings put system scroll_friction 0.010
settings put system touch_latency 0
settings put system touch_sampling_rate 240
settings put system touch_report_rate 240
settings put global touch_sampling_rate 240
settings put global touch_report_rate 240
settings put global touch_boost 1
settings put global touch_boost_enabled 1
settings put global low_latency_touch 1
settings put global touch_response_boost 1
settings put global fast_input_enabled 1
settings put secure tap_duration_threshold 30
settings put secure long_press_timeout 200
settings put system long_press_timeout 200
settings put system pointer_snap_enabled 1
settings put system pointer_magnetic_strength 200
settings put system touch_snap_radius 50
settings put system recoil_compensation_enabled 1
settings put system aim_assist_strength 100
settings put system head_tracking_enabled 1
settings put system touch_jitter_filter 0
settings put system touch_noise_threshold 0
cmd device_config put touchscreen input_drag_min_switch_speed 999

# Network & DNS Optimization
settings put system ping_optimizer true
settings put system target_ping 20
settings put system packet_loss_reduction true
settings put system network_buffer optimized
settings put system wifi_5ghz_preferred true
settings put system mobile_data_optimized true
settings put system prefer_5g true
settings put system use_custom_dns true
settings put system primary_dns 1.1.1.1
settings put system secondary_dns 8.8.8.8
settings put system dns_over_https true
settings put system tcp_fastopen true
settings put system prioritize_game_packets true
settings put system congestion_control bbr
settings put system qos_enabled true

# Memory (ZRAM, LMK) & Processes
settings put global zram_enabled 1
settings put global zram_compression_algorithm lz4
settings put global zram_compression_level 3
settings put global vm_swappiness 50
settings put global low_memory_killer_enable 1
settings put global trim_cache_on_low_mem 1
settings put global max_cached_processes 8
settings put global max_background_processes 4
settings put global gaming_memory_constants "gaming_memory_alloc_size=4096, gaming_memory_optimize=true, memory_gc_threshold=50000, memory_swap_enable=true, large_cache_threshold=500000, low_memory_threshold_game=256000, gaming_memory_pinning=true, memory_prefetch_enable=true, gaming_memory_dynamic_allocation=true, gaming_memory_swap_size=1024000"
settings put global app_process_constants "bg_start_timeout=1000, fg_start_timeout=300, app_process_max=2048, service_restart_duration=1000, service_restart_duration_factor=1, bg_anr_timeout=3000, fg_anr_timeout=4000"
device_config put activity_manager max_cached_processes 128
device_config put activity_manager max_phantom_processes 64
pm trim-caches 9999999999

# UI Animations & Background limits
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5
settings put global disable_window_animation 1
settings put global force_all_apps_standby true
settings put global force_background_check true
settings put global disable_auto_sync 1
settings put global wifi_scan_always_enabled 0
settings put global ble_scan_always_enabled 0
settings put global adaptive_battery_management 0
settings put global battery_saver_enabled 0
settings put global disable_battery_limit 1
settings put global fast_charge_enabled 1
cmd deviceidle enable
cmd deviceidle enable deep
cmd deviceidle enable light

# Disable GMS & Logging Bloat (System-wide background optimizer)
cmd appops set com.google.android.gms RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.gms RUN_ANY_IN_BACKGROUND ignore
cmd appops set com.google.android.gms START_FOREGROUND ignore
settings put global dropbox:dumpsys:procstats 0
settings put global dropbox:dumpsys:usagestats 0
cmd window logging disable
cmd window logging disable-text
cmd window tracing stop
settings put secure gb_boosting 1 
 settings put secure vtb_boosting 1
 settings put global miui_cpu_model 2
 settings put global miui_power_save 0
 settings put global miui_thermal_policy
 settings put global miui_cpu_model 0
 settings put global miui_cpu_model 1
 settings put global miui_cpu_model 2
 setprop debug.hwui.force_msaa 0
 setprop debug.hwui.force_fxaa 0
 setprop debug.hwui.force_smaa 0
 setprop debug.hwui.force_msaa 0
 setprop debug.hwui.force_txaa 0
 setprop debug.hwui.force_csaa 0
 setprop debug.hwui.force_dlss 0
 setprop debug.egl.force_msaa 0
 setprop debug.egl.force_fxaa 0
 setprop debug.egl.force_smaa 0
 setprop debug.egl.force_msaa 0
 setprop debug.egl.force_txaa 0
 setprop debug.egl.force_csaa 0
 setprop debug.egl.force_dlss 0
 setprop debug.egl.force_dmsaa 0
 settings put global hwui.disable_vsync true
 settings put global force_hw_ui true
settings put global persist.sampling_profiler 0
settings put global persist.sys.pugerable_assets 1
settings put global touch.pressure.scale 0.001
settings put system persist.sys.scrollingcache 3
cmd thermalservice override-status 0
cmd power set-fixed-performance-mode-enabled true
cmd device_config put game_overlay "$pkg" mode=3,highPerformanceMode=true
cmd device_config put game_overlay "$pkg" mode=3,optimizeCPUUsage=true
cmd device_config put game_overlay "$pkg" mode=3,gpuOverclock=enabled
cmd device_config put game_overlay "$pkg" mode=3,disablePowerSaving=true
cmd device_config put game_overlay "$pkg" mode=3,refreshRate=144
cmd device_config put game_overlay "$pkg" mode=2,skiagl=1,downscaleFactor=0.9,fps=250
cmd device_config put game_overlay "$pkg" mode=2,particleEffects=low
cmd device_config put game_overlay "$pkg" mode=2,textureQuality=low 
cmd device_config put game_overlay "$pkg" mode=2,disableSpecialEffects=true
setprop debug.OVRPlugin.systemDisplayFrequency 120
setprop debug.OVRManager.cpuLevel 3
setprop debug.OVRManager.gpuLevel 3
setprop debug.sf.early_phase_offset_ns 1500000
setprop debug.sf.enable_gl_backpressure 1
setprop debug.cpurend.vsync false
setprop debug.hwui.use_buffer_age false
setprop debug.hwui.force_gpu 1
setprop debug.hwui.use_fast_path 1
setprop debug.hwui.enable_threaded_render 1
setprop debug.hwui.optimize_rendering 1
setprop debug.hwui.enable_partial_render 1
setprop debug.hwui.texture_pool 512
setprop debug.hwui.max_texture_size 4096
setprop debug.sf.multithreaded_present true
setprop debug.sf.enable_hwc_vds 1
setprop debug.performance.tuning 1
setprop debug.texture.scale 16
setprop debug.performance_schema 1
setprop debug.performance_schema_max_memory_classes 320
setprop debug.performance_schema_max_socket_classes 10
setprop debug.composition.type mdp
setprop debug.composition.type2 gpu
setprop debug.gr.swapinterval 0
setprop debug.systemuicompilerfilter speed
setprop debug.rs.precision rs_fp_full
setprop debug.sf.latch_unsignaled 0
setprop debug.sf.disable_backpressure 1
setprop debug.hwui.disabledither false
 settings put system debug.cpurend.vsync false
 settings put system debug.gpurend.vsync false
 settings put global PERF_RES_FPS_FPSGO_LLF_TH 100
 settings put global PERF_RES_FPS_FPSGO_LLF_POLICY 1
 settings put global PERF_RES_FPS_FPSGO_LLF_LIGHT_LOADING_POLICY 20
 settings put global PERF_RES_FPS_FBT_RESCUE_F 90
 settings put global PERF_RES_FPS_FBT_QR_T2WNT_Y_P 10
 settings put global PERF_RES_FPS_FBT_QR_T2WNT_Y_N 10
 settings put global PERF_RES_FPS_FBT_GCC_ENQ_BOUND_THRS 20
 settings put global PERF_RES_FPS_FBT_GCC_DEQ_BOUND_THRS 20
 settings put global PERF_RES_FPS_FBT_GCC_DEQ_BOUND_QUOTA 6
 settings put global PERF_RES_FPS_FBT_GCC_DOWN_QUOTA_PCT 50
 settings put global PERF_RES_FPS_FPSGO_IDLEPREFER 0
 settings put global PERF_RES_FPS_FPSGO_SPID 1
 settings put global PERF_RES_FPS_GBE1_ENABLE 1
 settings put global PERF_RES_FPS_GBE2_ENABLE 1
 settings put global PERF_RES_FPS_GBE2_TIMER2_MS1 1000
 settings put global PERF_RES_FPS_GBE2_MAX_BOOST_CNT 10
 settings put global PERF_RES_FPS_GBE2_TIMER1_MS 150
 settings put global PERF_RES_FPS_GBE_POLICY_MASK 87
 settings put global PERF_RES_FPS_FBT_CEILING_ENABLE 1
 settings put global PERF_RES_GPU_GED_MARGIN_MODE 110
 settings put global PERF_RES_GPU_FREQ_MAX 100
 settings put global PERF_RES_FPS_FPSGO_BOOST_LR 1
 settings put global PERF_RES_FPS_FBT_ULTRA_RESCUE 1
 settings put global PERF_RES_FPS_FBT_RESCUE_SECOND_GROUP 1
 settings put global PERF_RES_FPS_FBT_RESCUE_SECOND_TIME 1
 settings put global PERF_RES_FPS_FBT_RESCUE_SECOND_ENABLE 1
 settings put global PERF_RES_FPS_FBT_GCC_FPS_MARGIN 120
 settings put global touch_boost 1
 settings put global touch_boost_enabled 1
 settings put global low_latency_touch 1
 settings put global touch_response_boost 1
 settings put global fast_input_enabled 1
cmd thermalservice override-status 2
cmd thermalservice inject-temperature CPU moderate CPU 99.999
cmd thermalservice inject-temperature GPU moderate GPU 99.999
cmd thermalservice inject-temperature NPU moderate NPU 99.999
cmd thermalservice inject-temperature TPU moderate TPU 99.999
cmd thermalservice inject-temperature MODEM moderate MODEM 99.999 
cmd thermalservice inject-temperature SKIN moderate SKIN 99.999
cmd thermalservice inject-temperature BATTERY moderate BATTERY 99.999
cmd thermalservice inject-temperature POWER_AMPLIFIER moderate POWER_AMPLIFIER 99.999
cmd thermalservice inject-temperature CPU0 moderate CPU0 99.999
cmd thermalservice inject-temperature CPU1 moderate CPU1 99.999
cmd thermalservice inject-temperature CPU1 moderate CPU1 99.999
cmd thermalservice inject-temperature CPU2 moderate CPU2 99.999
cmd thermalservice inject-temperature CPU3 moderate CPU3 99.999
cmd thermalservice inject-temperature CPU4 moderate CPU4 99.999
cmd thermalservice inject-temperature CPU5 moderate CPU5 99.999
cmd thermalservice inject-temperature CPU6 moderate CPU6 99.999
cmd thermalservice inject-temperature CPU7 moderate CPU7 99.999
cmd thermalservice inject-temperature GPU0 moderate GPU0 99.999
cmd thermalservice inject-temperature GPU1 moderate GPU1 99.999
cmd thermalservice inject-temperature GPU2 moderate GPU2 99.999
cmd thermalservice inject-temperature GPU3 moderate GPU3 99.999
cmd thermalservice inject-temperature nsp0 moderate nsp0 99.999
cmd thermalservice inject-temperature nsp1 moderate nsp1 99.999
cmd thermalservice inject-temperature nsp2 moderate nsp2 99.999
cmd thermalservice inject-temperature nsp3 moderate nsp3 99.999
cmd thermalservice inject-temperature socd moderate socd 99.999
cmd thermalservice inject-temperature ibat moderate ibat 99.999
cmd thermalservice inject-temperature vbat moderate vbat 99.999
cmd thermalservice inject-temperature battery moderate battery 99.999
cmd thermalservice inject-temperature skin moderate skin 99.999
setprop debug.thermal_control 1
setprop debug.thermal.disable_cgroup_thermal 0
setprop debug.thermal.bypass false
setprop debug.disable.thermal.control 0
setprop debug.disable.usb.overheat.mitigation 0
setprop debug.thermal.throttle.support yes
setprop debug.cpu.cooling.callback_freq_limit true
setprop debug.gpu.cooling.callback_freq_limit true
settings put system gamelowtemp_enable 1
settings put system gamelowtemp_ignoreicon 1
settings put system lowtempgame ""
settings put system lowtemp_scgthres "2048:3072:5:-160,4096:5120:200:-105,0:0:0:-160,2048:3072:5:-160"
settings put system oplus_customize_comfort_color_temperature_enable 1
settings put system oplus_settings_hightemp_protect 1
settings put system oplus_settings_hightemp_safety_state 1
settings put system oplus_customize_thermal_control_optimization_number 45
settings put system thermal_limit_mode 1
settings put system rt_enable_templimit true
settings put system settings_thermal_high 0
settings put system tran_board_temperature 44.444
settings put system tran_default_temperature_index 14
settings put secure pc_low_temperature_extreme_endurance_switch 1
settings put secure allowed_kill_battery_temp_threshhold 45
settings put secure thermal_temp_state_value 1
settings put secure thermal_safety_mode 1
settings put secure game_auto_temperature 1
settings put secure game_auto_temperature_control 1
settings put secure sysui_nav_bar_temp "left[.5W],recent[1WC];home;back[1WC],right[.5W]"
settings put secure customize_power_temperature_control_hbm 1
settings put secure customize_power_temperature_control_osie 1
settings put secure customize_power_temperature_control_videosr 1
settings put global warning_temperature 1
settings put global game_temperature_control 1
settings put global tran_temp_battery_warning 1
settings put global sem_low_heat_mode 0
settings put global oppo.thermal.optimization_mode 1
settings put global oneplus_thermal_mode 1
settings put global disable_threshold 0
settings put global badging_thresholds 1
settings put global show_usb_temperature_alarm 1
settings put global show_temperature_warning 1
settings put global tran_temp_battery_warning 1
settings put global warning_temperature 1
settings put global sem_low_heat_mode 0
settings put global thermal_limit_gpu 85
setprop persist.sys.thermal.enable 1
setprop persist.sys.thermal_policy_update 1
setprop persist.sys.enable_templimit true
# network ON
# DNS Optimization (via settings – no root needed)
settings put global private_dns_mode off
settings put global dns_resolver_sample_validity_seconds 1800
settings put global dns_resolver_min_samples 8
settings put global dns_resolver_max_samples 64

# WiFi performance
settings put global wifi_sleep_policy 2
settings put global wifi_scan_throttle_enabled 0
settings put global wifi_scan_always_enabled 0
settings put global wifi_networks_available_notification_on 0

# Mobile data tweaks
settings put global mobile_data_always_on 1
settings put global network_recommendations_enabled 0
settings put global network_scoring_ui_enabled 0

# Reduce captive portal checks
settings put global captive_portal_detection_enabled 0
settings put global captive_portal_server ""

# Background data (do not restrict)
settings put global restrict_background 0

# TCP Fast Open (enable via system property if writable; fallback to setting)
# Some devices allow this via cmd, but if not, we skip
# cmd device_config put netd_native tcp_fastopen 3   # may not work everywhere, comment out if unsupported

# Keep WiFi on during sleep
settings put global wifi_idle_ms 300000

# Disable Wi‑Fi verbose logging
cmd wifi set-verbose-logging disabled

# Remove all Wi‑Fi suggestions
cmd wifi remove-all-suggestions
# ==========================================
# 1. CẢM ỨNG & ĐỘ TRỄ (TOUCH & GESTURES)
# ==========================================
settings put system pointer_speed 5
settings put system touch_slop 2
settings put secure long_press_timeout 250
settings put secure multi_press_timeout 250
settings put global touch_sampling_rate 240
settings put system touch_sampling_rate 240
settings put global touch_report_rate 240
settings put global touch_boost 1
settings put global touch_boost_enabled 1
settings put global low_latency_touch 1
settings put global touch_response_boost 1
settings put global fast_input_enabled 1
settings put system haptic_feedback_enabled 0
settings put system sound_effects_enabled 0
settings put system show_touches 0
setprop debug.touch.sampling_rate 240
setprop debug.touchscreen.report_rate 2
setprop debug.input.event_delay 1
setprop persist.vendor.qti.inputopts.enable true
setprop persist.vendor.qti.inputopts.movetouchslop 0.6

# ==========================================
# 2. MẠNG & PING (NETWORK & DNS)
# ==========================================
settings put global wifi_sleep_policy 2
settings put global mobile_data_always_on 1
settings put global tcp_default_init_rwnd 60
settings put global netstats_enabled 0
settings put system ping_optimizer true
settings put system target_ping 20
settings put system packet_loss_reduction true
settings put system network_buffer optimized
settings put system tcp_fastopen true

# Tắt các dịch vụ theo dõi mạng chạy ngầm (Đã gỡ vòng lặp)
settings put global netpolicy_override_enabled 0
settings put global netpolicy_quota_enabled 0
settings put global netpolicy_quota_frac_jobs 0
settings put global netpolicy_quota_frac_multipath 0
settings put global netpolicy_quota_limited 0
settings put global netpolicy_quota_unlimited 0
settings put global netstats_augment_enabled 0
settings put global netstats_combine_subtype_enabled 0
settings put global netstats_dev_bucket_duration 0
settings put global netstats_dev_delete_age 0
settings put global netstats_dev_persist_bytes 0
settings put global netstats_dev_rotate_age 0
settings put global netstats_global_alert_bytes 0
settings put global netstats_poll_interval 0
settings put global netstats_sample_enabled 0
settings put global netstats_time_cache_max_age 0
settings put global netstats_uid_bucket_duration 0
settings put global netstats_uid_delete_age 0
settings put global netstats_uid_persist_bytes 0
settings put global netstats_uid_rotate_age 0
settings put global netstats_uid_tag_bucket_duration 0
settings put global netstats_uid_tag_delete_age 0
settings put global netstats_uid_tag_persist_bytes 0
settings put global netstats_uid_tag_rotate_age 0
settings put global network_avoid_bad_wifi 0
settings put global network_default_daily_multipath_quota_bytes 0
settings put global network_location_opt_in 0
settings put global network_metered_multipath_preference 0
settings put global network_preference 0
settings put global network_recommendations_enabled 0
settings put global network_recommendations_package 0
settings put global network_scorer_app 0
settings put global network_scoring_provisioned 0
settings put global network_scoring_ui_enabled 0
settings put global network_switch_notification_daily_limit 0
settings put global network_switch_notification_rate_limit_millis 0
settings put global network_watchlist_enabled 0
settings put global network_watchlist_last_report_time 0

# ==========================================
# 3. HOẠT ẢNH & ĐỒ HỌA (UI ANIMATIONS & RENDER)
# ==========================================
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5
settings put global disable_hw_overlays 1
settings put system hwui.disable_vsync true
settings put system ro.config.enable.hw_accel true
setprop debug.composition.type gpu
setprop debug.hwui.renderer skiagl
setprop debug.renderengine.backend skiaglthreaded
setprop debug.sf.hw 1
setprop debug.egl.hw 1
setprop debug.cpurend.vsync false
setprop debug.gpurend.vsync false
setprop debug.gr.swapinterval 0
setprop debug.egl.swapinterval 0
setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_hwc_vds 1
settings put global rendering_type skiavk
settings put global tag GraphicsEnvironment
settings put global system_driver_name system
settings put global system_driver_version_name ""
settings put global system_driver_version_code 0
settings put global property_gfx_driver ro.apex.updatable
settings put global property_gfx_driver_production ro.apex.updatable
settings put global property_gfx_driver_prerelease ro.gfx.angle.supported
settings put global property_gfx_driver_build_time ro.gfx.angle.supported
settings put global property_ro_hardware_egl persist.graphics.egl
settings put global metadata_driver_build_time com.android.angle
settings put global metadata_developer_driver_enable org.chromium.angle
settings put global metadata_inject_layers_enable org.chromiuim.angle
settings put global game_driver_preference com.android.angle,org.chromium.angle
settings put global game_driver_global_opt_in_default 0
settings put global game_driver_global_opt_in_game_driver 1
settings put global game_driver_global_opt_in_prerelease_driver 2
settings put global game_driver_global_opt_in_off 3
settings put global angle_rules_file a4a_rules.json
settings put global angle_temp_rules debug.angle.rules
settings put global vulkan_1_0 0x00400000
settings put global vulkan_1_1 0x00401000
settings put global vulkan_1_2 0x00402000
settings put global vulkan_1_3 0x00403000
settings put global vulkan_1_4 0x00404000
settings put global feature_vulkan_hardware_version vulkan_1_4
settings put global trace_tag_graphics setupGpuLayers
settings put global updatable_driver_global_opt_in_default 0
settings put global updatable_driver_global_opt_in_production_driver 1
settings put global updatable_driver_global_opt_in_prerelease_driver 2
settings put global updatable_driver_global_opt_in_off 3
settings put global angle_driver_name angle
settings put global action_angle_for_android "android.app.action.ANGLE_FOR_ANDROID"
settings put global action_angle_for_android_toast_message "android.app.action.ANGLE_FOR_ANDROID_TOAST_MESSAGE"
settings put global intent_key_a4a_toast_message "A4A Toast Message"
settings put global angle_gl_driver_all_angle_on 1
settings put global angle_gl_driver_all_angle_off 0
settings put global angle_gl_driver_choice_default default
settings put global angle_gl_driver_choice_angle angle
settings put global angle_gl_driver_choice_native native
settings put global system_angle_string system
settings put system game_driver_preference "org.chromium.angle,com.android.angle"
setprop debug.angle.libs.suffix "org.chromium.angle.apk,com.android.angle.apk"
setprop debug.graphics.angle.developeroption.enable 1
setprop debug.angle.capture.enabled 1
setprop debug.angle.capture.out_dir foo
setprop debug.angle.capture.label bar
setprop debug.angle.capture.trigger 100
setprop debug.angle.capture.frame_start 1
setprop debug.angle.capture.frame_end 100
settings put global enable_gpu_debug_layers 1
# ==========================================
# 4. TẦN SỐ QUÉT & FPS (120HZ UNLOCK)
# ==========================================
settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120
settings put secure user_refresh_rate 120
settings put global min_fps 120
settings put global max_fps 120
settings put system fps.limit.is.now locked
setprop persist.sys.display_refresh_rate 120
setprop persist.sys.display.fps 120
setprop debug.sf.frame_rate_multiple_threshold 0
setprop debug.sf.scroll_boost_refreshrate 120
setprop debug.sf.touch_boost_refreshrate 120

# ==========================================
# 5. HIỆU NĂNG CPU/GPU & PIN (PERFORMANCE)
# ==========================================
cmd power set-fixed-performance-mode-enabled true
cmd power set-adaptive-power-saver-enabled false
cmd thermalservice override-status 0
device_config put thermal disable_thermal_throttling 1
device_config put thermal prefer_cool_device 1
settings put global app_standby_enabled 0
settings put secure speed_mode_enable 1
setprop debug.performance.tuning 1
setprop debug.cpuprio 7
setprop debug.gpuprio 7
setprop debug.rs.max-threads 8
setprop debug.rs.min-threads 8

# Dọn dẹp Cache & Bộ nhớ ảo
cmd device_config put activity_manager max_cached_processes 128
pm trim-caches 9999999999

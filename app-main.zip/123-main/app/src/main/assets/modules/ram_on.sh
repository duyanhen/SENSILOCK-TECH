# ram ON
cmd activity idle-maintenance

cmd package bg-dexopt-job

cmd activity send-trim-memory com.dts.freefireth RUNNING_CRITICAL
cmd activity send-trim-memory com.dts.freefiremax RUNNING_CRITICAL

cmd power set-fixed-performance-mode-enabled true

settings put global cached_apps_freezer enabled

settings put global activity_manager_constants max_cached_processes 96

settings put global activity_manager_constants \
"max_cached_processes=96,background_settle_time=60000,gc_timeout=5000,gc_min_interval=60000,full_pss_min_interval=1200000,full_pss_lowered_interval=300000,power_check_interval=300000"

settings put global settings_enable_monitor_phantom_procs false

settings put global sem_enhanced_cpu_responsiveness 1

settings put global ram_expand_size_list 0,1,2,4,6,8

settings put secure speed_mode 1

setprop persist.sys.purgeable_assets 1

setprop persist.sys.trim_enabled 1

setprop persist.sys.lmk.reportkills false

setprop persist.sys.lmk.debug false

setprop persist.device_config.runtime_native.use_app_image_startup_cache true

setprop dalvik.vm.heapstartsize 16m

setprop dalvik.vm.heapgrowthlimit 256m

setprop dalvik.vm.heapsize 512m

setprop dalvik.vm.heaptargetutilization 0.75

setprop dalvik.vm.heapminfree 8m

setprop dalvik.vm.heapmaxfree 32m

setprop ro.lmk.low 1001

setprop ro.lmk.medium 800

setprop ro.lmk.critical 0

setprop ro.config.low_ram false

setprop persist.sys.zram_enabled 1

setprop persist.sys.zram_size 2147483648

setprop persist.sys.fuse.passthrough.enable true

setprop debug.kill_allocating_task 0

setprop debug.sf.enable_hwc_vds 1

setprop debug.hwui.renderer skiagl

setprop debug.hwui.disable_vsync false

setprop debug.hwui.use_hint_manager true

setprop debug.performance.tuning 1

setprop video.accelerate.hw 1

setprop debug.sf.latch_unsignaled 1

setprop persist.sys.ui.hw 1

setprop persist.sys.use_dithering 1

setprop persist.sys.scrollingcache 3

setprop windowsmgr.max_events_per_sec 240

setprop persist.sys.NV_FPSLIMIT 120

setprop persist.sys.NV_POWERMODE 1

setprop persist.sys.smartpower 0

setprop persist.sys.background_apps_limit 8

setprop persist.sys.fflag.override.settings_enable_monitor_phantom_procs false


# =========================
# [FREE RAM BOOST]
# =========================

cmd activity compact com.dts.freefireth
cmd activity compact com.dts.freefiremax

cmd activity force-stop com.facebook.katana
cmd activity force-stop com.facebook.orca
cmd activity force-stop com.google.android.youtube

cmd jobscheduler run -f android 999

cmd thermalservice override-status 0

cmd power set-adaptive-power-saver-enabled false

cmd netpolicy set restrict-background false
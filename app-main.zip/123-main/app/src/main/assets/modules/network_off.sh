# network OFF
settings delete global private_dns_mode
settings delete global dns_resolver_sample_validity_seconds
settings delete global dns_resolver_min_samples
settings delete global dns_resolver_max_samples
settings put global wifi_sleep_policy 0
settings put global wifi_scan_throttle_enabled 1
settings put global wifi_scan_always_enabled 1
settings put global wifi_networks_available_notification_on 1
settings put global mobile_data_always_on 0
settings put global network_recommendations_enabled 1
settings put global network_scoring_ui_enabled 1
settings put global captive_portal_detection_enabled 1
settings put global captive_portal_server "connectivitycheck.gstatic.com"
settings put global restrict_background 1
cmd wifi set-verbose-logging enabled
# cmd wifi remove-all-suggestions has no reset
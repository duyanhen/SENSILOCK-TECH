# FPS Boost - BAT
# Target FPS
settings put system fps_limit 120
settings put system max_render_frame_rate 120
settings put global min_fps 120
settings put global max_fps 120

# Disable Thermal Refresh Rate Limit
settings put system thermal_limit_refresh_rate 0

# Force FPS Properties
setprop debug.sf.frame_rate 120
setprop debug.sf.frame_rate_priority 1
setprop debug.sf.use_frame_rate_priority 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.frame_rate_multiple_threshold 0
setprop debug.sf.hwc_disable_vsync 1
setprop debug.hwui.disable_vsync true

# Swap Interval to 0 (Uncap FPS)
setprop debug.egl.swapinterval 0
setprop debug.gr.swapinterval 0
setprop debug.sf.swapinterval 0
# Cấu hình Settings cho FPS
settings put system max_render_frame_rate 120
settings put system target_fps 120
settings put global min_fps 120
settings put global max_fps 120
settings put system is_smart_fps 0
settings put global persist.sys.frame_rate 120

# Cấu hình FPS Properties cho SurfaceFlinger (sf) & HWUI
setprop debug.sf.frame_rate_priority 1
setprop debug.sf.frame_rate 120
setprop debug.sf.frame_rate_lock 120
setprop debug.sf.frame_rate_override 120
setprop debug.sf.frame_rate_policy stable
setprop debug.sf.limit_fps 120
setprop debug.sf.force_fps 120
setprop debug.sf.animation.framerate 120
setprop debug.unlock.fps 120
setprop debug.egl.fps_override 120
setprop debug.hwui.fpslimit 120
setprop debug.hwui.fps_limit 120
setprop debug.javafx.animation.framerate 120
setprop debug.fps.is.now locked

# Tắt Vsync & Chỉnh Swap Interval (Giảm Input Lag)
setprop debug.sf.swapinterval 0
setprop debug.gr.swapinterval 0
setprop debug.egl.swapinterval 0
setprop debug.gl.swapinterval 0
setprop debug.hwui.disable_vsync true
setprop debug.cpurend.vsync false
setprop debug.gpurend.vsync false
setprop debug.sf.disable_vsync 1
setprop debug.hwc.force_gpu_vsync 1
setprop debug.graphics.game_default_frame_rate.disabled true
settings put system pointer_speed 7
settings put system touch_sensitivity 1.5
settings put system touch_slop 2
settings put system ui.hw 1
settings put system MovementSpeedRatio 1.5
settings put system ZoomSpeedRatio 1.5
settings put system SwipeTransitionAngleCosine 0.5
settings put system touch_switch_set_touchscreen 14005
settings put system long_press_timeout 259
settings put system multi_press_timeout 25
settings put system pointer_gesture_duration 25
settings put system DragMinSwitchSpeed 99999.0px/s
settings put system SwipeMaxWidthRatio 1
settings put system touchscreen_sensitivity_threshold 9
settings put system touchscreen_double_tap_speed 75
settings put system touchscreen_sensitivity_scale 1.5
settings put system touchscreen_min_press_time 50
settings put system touchscreen_pointer_speed 15
settings put global mot.proximity.distance 1
settings put global mot.proximity.delay 35
settings put global PointerVelocityControlParameters 1
settings put secure long_press_timeout 300
settings put secure multi_press_timeout 300

settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5
settings put system windowsmgr.max_events_per_sec 120
settings put system windowsmgr.animation_scale 0
settings put system windowsmgr.transition_scale 0

settings put system vm.min_free_kbytes 8192
settings put system vm.dirty_background_ratio 60
settings put system vm.dirty_ratio 95
settings put system vm.vfs_cache_pressure 20
settings put system vm.overcommit_memory 0
settings put system vm.page-cluster 3
settings put system vm.overcommit_ratio 50

cmd thermalservice override-status 0
cmd power set-fixed-performance-mode-enabled true
cmd power set-adaptive-power-saver-enabled false
cmd power set-mode 0

settings put global power_check_max_cpu_1 75
settings put global power_check_max_cpu_2 75
settings put global power_check_max_cpu_3 50
settings put global power_check_max_cpu_4 50
settings put system power.throttling.disable 1
settings put system thermal.gpu_shader_clock_throttle.disable 1
settings put system thermal.gpu_core_clock_throttle.disable 1

device_config put thermal gpu_power_throttle.disable 1
device_config put thermal gpu_thermal_throttle.disable 1
device_config put thermal gpu_memory_throttle.disable 1
device_config put thermal gpu_fan_control.disable 1
device_config put thermal gpu_boost.disable 1
device_config put thermal gpu_control.disable 1
device_config put thermal gpu_throttle.disabled 1
device_config put thermal throttling.disable 1
device_config put thermal profile.disable 1
device_config put thermal dynamic_scheduling.disable 1
device_config put thermal thermal_policy.disable 1
device_config put thermal cpu_thermal_throttle.disable 1
device_config put thermal disable_thermal_throttling 1
device_config put thermal prefer_cool_device 1

device_config put activity_manager fstrim_mandatory_interval 1
device_config put lmkd_native thrashing_limit_critical 500
device_config put activity_manager bg_current_drain_auto_restrict_abusive_apps_enabled true
device_config put activity_manager_native_boot use_freezer true
device_config put activity_manager max_cached_processes 128
device_config put activity_manager max_phantom_processes 2147483647

settings put system surface_flinger_use_frame_rate_api true
settings put system hw3d.force 1
settings put system hwui.disable_vsync true
settings put system hwui.render_dirty_regions false
settings put system ro.config.enable.hw_accel true
settings put system ro.product.gpu.driver 1
settings put system ro.fb.mode 1
settings put system video.accelerate.hw 1
settings put system HardwareAccelerated true
settings put system HardwareRenderer.Accelerated 1
settings put system gpu_mode host
settings put system gpu_option_mode host
settings put system game.accelerate.hw 1
settings put system peak_refresh_rate 120
settings put system minimum_refresh_rate 120
settings put secure user_refresh_rate 120

setprop debug.sys.display.fps 120
setprop debug.sys.display_refresh_rate 120
setprop debug.sys.game.maxfps 120
setprop debug.hwui.renderer skiagl
setprop debug.composition.type gpu
setprop debug.composition.type c2d
setprop debug.egl.hw 1
setprop debug.sf.hw 1
setprop debug.enabletr true
setprop debug.gralloc.gfx_ubwc_disable 0
setprop debug.performance.tuning 1
setprop debug.gr.swapinterval 0
setprop debug.egl.swapinterval 0
setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_gl_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_hwc_vds 1
setprop debug.hwui.disable_fbo_cache true
setprop debug.hwui.disable_gpu_cache true
setprop debug.hwui.disable_picture_cache true
setprop debug.hwui.disable_text_cache true
setprop debug.hwui.disable_path_cache true
setprop debug.hwui.disable_asset_cache true
setprop debug.hwui.disable_vsync true
setprop debug.hwui.render_dirty_regions false
setprop debug.cpurend.vsync false
setprop debug.gpurend.vsync false
setprop debug.rs.max-threads 8
setprop debug.rs.min-threads 8
setprop debug.rs.max-freq 3800000
setprop debug.rs.min-freq 3800000
setprop debug.rs.min-perf_percent 100
setprop debug.javafx.animation.fullspeed true
setprop debug.javafx.animation.framerate 120
setprop debug.sf.animation.framerate 120
setprop debug.rs.animation.framerate 120
setprop debug.systemuicompilerfilter speed
setprop debug.app.performance_restricted false
setprop debug.sf.showupdates 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.showfps 0
setprop debug.hwc.logvsync 0
setprop debug.hwc.force_gpu_vsync 1
setprop debug.hwc.asyncdisp 1
setprop debug.cpuprio 7
setprop debug.gpuprio 7
setprop debug.ioprio 7
setprop debug.force_gpu_rendering 1

setprop debug.hwui.force_msaa 0
setprop debug.hwui.force_fxaa 0
setprop debug.hwui.force_smaa 0
setprop debug.hwui.force_txaa 0
setprop debug.hwui.force_csaa 0
setprop debug.hwui.force_dlss 0
setprop debug.egl.force_msaa 0
setprop debug.egl.force_fxaa 0
setprop debug.egl.force_smaa 0
setprop debug.egl.force_txaa 0
setprop debug.egl.force_csaa 0
setprop debug.egl.force_dlss 0
setprop debug.egl.force_dmsaa 0

setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.high_fps_early_phase_offset_ns 6100000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 650000
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000

# touch OFF
settings delete system pointer_speed
settings delete system touch_sensitivity
settings delete system touch_slop
settings delete secure long_press_timeout
settings delete secure multi_press_timeout
settings delete system touchscreen_sensitivity
settings delete system touchscreen_min_press_time
settings delete system touchscreen_pointer_speed
settings delete system touchscreen_double_tap_speed
settings delete system touchscreen_sensitivity_scale
settings delete system touchfeature.gamemode.enable
settings delete system touch_sensitivity_enabled
settings delete global block_untrusted_touches
settings delete system show_touches
settings delete system haptic_feedback_enabled
settings delete system sound_effects_enabled
settings delete system vibrate_on
settings delete system view_scroll_friction
settings delete global touch_boost_enabled
settings delete global low_latency_touch
settings delete global touch_response_boost
settings delete global fast_input_enabled
settings delete global touch_sampling_rate
settings delete system touch_sampling_rate
settings delete global touch_report_rate
settings delete system touch_report_rate
settings delete global smooth_scroll
settings delete system input_dispatching_timeout_ms
settings delete system pointer_acceleration
settings delete global PointerVelocityControlParameters
settings delete global DragMinSwitchSpeed
settings delete global SwipeMaxWidthRatio
settings delete system MovementSpeedRatio
settings delete system ZoomSpeedRatio
settings delete system touch_switch_set_touchscreen
settings delete system long_press_timeout
settings delete system multi_press_timeout
settings delete system pointer_gesture_duration
settings delete system mot_proximity_delay
settings delete system TouchScreen_sampling_rate
settings delete system touch.orientationAware
settings delete system touch.pressure.scale
settings delete system touch.size.scale
settings delete system touch.distance.scale
settings delete system multitouch_distance_scale
settings delete system scrollingcache
settings delete system edge_slop
settings delete system overscroll_distance
settings delete system overfling_distance
settings delete system fling_velocity
settings delete system tap_timeout
settings delete system double_tap_timeout
settings delete security long_press_timeout
settings delete security multi_press_timeout
setprop debug.touch.deviceType ""
setprop debug.touch.sampling_rate ""
setprop debug.touchscreen.report_rate ""
setprop debug.input.event_delay ""
setprop debug.touch_sensitivity_mode ""
setprop debug.MultitouchSettleInterval ""
setprop debug.TapInterval ""
setprop debug.TapSlop1px ""
setprop debug.sf.scroll_boost_refreshrate ""
setprop debug.sf.touch_boost_refreshrate ""
setprop debug.touch.pressure.scale ""
setprop debug.touch_move_opt ""
setprop debug.touch_vsync_opt ""
setprop debug.touch.size.bias ""
setprop debug.touch.calibrate ""
setprop debug.touch.delay ""
setprop debug.touch.response ""
setprop debug.touch.pollrate ""
setprop debug.touch.sensitivity ""
setprop debug.touch.tap_timeout ""
setprop debug.touch.longpress_timeout ""
setprop debug.touch.pressure_sensitivity ""
setprop debug.touch.slop ""
setprop debug.touch.velocity_scale ""
setprop debug.boosterorientnosync ""
setprop debug.sf.set_touch_timer_ms ""
setprop debug.performance.tuner.touch.software.oversampling ""
setprop debug.performance.tuner.touch.pressure.scale ""
setprop debug.performance.tuner.touch.responsiveness.averagemintime ""
setprop debug.inputdispatcher.max_events_per_sec ""
setprop debug.inputdispatcher.report_touch_event_delay ""
setprop debug.inputreader.velocity.control.resolution ""
setprop debug.inputreader.velocity.control.scale ""
setprop debug.inputreader.velocity.control.xscale ""
setprop debug.inputreader.velocity.control.yscale ""
setprop persist.vendor.qti.inputopts.enable ""
setprop persist.vendor.qti.inputopts.movetouchslop ""
setprop ro.product.multi_touch_enabled ""
setprop ro.product.max_num_touch ""
settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
settings delete global disable_hw_overlays
settings delete global force_fsg_nav_bar
settings delete global accessibility_reduce_motion
settings delete global fancy_ime_animations
settings delete global debug.layout
settings delete global show_processes
settings delete global one_handed_mode_enabled
settings delete global sysui_qs_tiles
settings delete global enable_gpu_debug_layers
settings put system pointer_speed 0
settings delete system touch_slop
setprop touch.pressure.scale ""
setprop debug.touch.pressure.scale ""
settings delete secure long_press_timeout
settings delete secure multi_press_timeout
settings delete global touch_boost
settings delete global touch_boost_enabled
settings delete system pointer_gesture_duration
settings delete system mot.proximity.distance
settings delete system mot.proximity.delay
setprop debug.touch.sampling_rate ""
setprop debug.input.event_delay ""
setprop debug.touchscreen.report_rate ""
settings delete system view.scroll_friction
settings delete global windowsmgr.max_events_per_sec
setprop debug.touch.deviceType ""
settings delete system MultitouchMinDistance
settings delete system MultitouchSettleInterval
setprop persist.vendor.qti.inputopts.enable ""
setprop persist.vendor.qti.inputopts.movetouchslop ""
settings delete system touch.filter.level
settings delete global block_untrusted_touches
settings delete system vsync.disable.fps.limit
settings delete global low_latency_touch
settings delete global touch_response_boost
settings delete global fast_input_enabled
settings delete system input_latency_reduction
settings delete system motion_jitter_fix
settings delete system haptic_feedback_enabled
settings delete global smooth_scroll
settings delete system show_touches
settings delete system pointer_location
setprop debug.choreographer.skipwarning ""
setprop debug.choreographer.vsync ""
# ==========================================
# 1. TỐI ƯU CẢM ỨNG & PHẢN HỒI (TOUCH & GESTURES)
# ==========================================
settings put system pointer_speed 5 # Đã hạ xuống 5 để tránh lỗi Invalid Value
settings put system touch_slop 2
settings put system touch_sensitivity 1.5
settings put system touch_sensitivity_enabled 1
settings put secure long_press_timeout 250
settings put secure multi_press_timeout 250

# Tăng tốc độ lấy mẫu và phản hồi
settings put global touch_sampling_rate 240
settings put system touch_sampling_rate 240
settings put global touch_report_rate 240
settings put system touch_report_rate 240
settings put global touch_boost 1
settings put global touch_boost_enabled 1
settings put global low_latency_touch 1
settings put global touch_response_boost 1
settings put global fast_input_enabled 1
settings put system pointer_gesture_duration 25
settings put global windowsmgr.max_events_per_sec 180
settings put system view_scroll_friction 0.003
settings put global smooth_scroll 1

# Tắt phản hồi phụ để giảm độ trễ
settings put system haptic_feedback_enabled 0
settings put system sound_effects_enabled 0
settings put system vibrate_on 0
settings put system show_touches 0
settings put system pointer_location 0
settings put global block_untrusted_touches 0

# Tối ưu nhận diện Proximity (Cảm biến tiệm cận)
settings put system mot.proximity.distance 1
settings put system mot.proximity.delay 35

# ==========================================
# 2. TỐI ƯU HOẠT ẢNH & ĐỒ HỌA UI (ANIMATIONS)
# ==========================================
settings put global window_animation_scale 0.4
settings put global transition_animation_scale 0.4
settings put global animator_duration_scale 0.4
settings put global disable_hw_overlays 1
settings put global accessibility_reduce_motion 1
settings put global fancy_ime_animations 0

# ==========================================
# 3. SETPROP TĂNG CƯỜNG CẢM ỨNG (DEBUG PROPS)
# ==========================================
setprop debug.touch.sampling_rate 240
setprop debug.touchscreen.report_rate 2
setprop debug.input.event_delay 1
setprop debug.touch_sensitivity_mode 1
setprop debug.touch.deviceType touchScreen

# Tối ưu cuộn và vuốt (SurfaceFlinger)
setprop debug.sf.scroll_boost_refreshrate 120
setprop debug.sf.touch_boost_refreshrate 120
setprop debug.sf.set_touch_timer_ms 100

# Tối ưu cho dòng chip Snapdragon (QTI Input Options)
setprop persist.vendor.qti.inputopts.enable true
setprop persist.vendor.qti.inputopts.movetouchslop 0.6

# Tối ưu luồng xử lý đầu vào
setprop debug.inputdispatcher.max_events_per_sec 240
setprop debug.inputdispatcher.report_touch_event_delay 0
setprop debug.performance.tuner.touch.software.oversampling 8
setprop debug.performance.tuner.touch.pressure.scale 0.6
setprop debug.performance.tuner.touch.responsiveness.averagemintime 1

# Đồng bộ khung hình (Choreographer)
setprop debug.choreographer.skipwarning true
setprop debug.choreographer.vsync true

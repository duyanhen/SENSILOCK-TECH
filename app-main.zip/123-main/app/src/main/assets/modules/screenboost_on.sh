# Screen Boost - BAT
settings put system min_refresh_rate 120
settings put system peak_refresh_rate 120
settings put system screen_brightness_mode 0
# Set Refresh Rate 120Hz
settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120
settings put secure refresh_rate_mode 2

# User Refresh Rate
settings put system user_refresh_rate 120
settings put secure user_refresh_rate 120

# MIUI Specific Refresh Rate
settings put secure miui_refresh_rate 120
# Cấu hình Settings cho System, Global và Secure
settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120
settings put system max_refresh_rate 120
settings put system user_refresh_rate 120
settings put system default_refresh_rate 120
settings put system refresh_rate 120
settings put system preferred_refresh_rate 120
settings put system miui_refresh_rate 120
settings put system thermal_limit_refresh_rate 0
settings put system tran_refresh_mode 1
settings put system tran_need_recovery_refresh_mode 1
settings put system refresh_rate_policy 1
settings put system ext_force_refresh_rate_list 120
settings put system db_screen_rate 2
settings put global preferred_refresh_rate 1
settings put global user_preferred_refresh_rate 1
settings put secure user_refresh_rate 120
settings put secure max_refresh_rate 120
settings put secure miui_refresh_rate 120
settings put secure refresh_rate_mode 2

# Cấu hình Device Config
device_config put display_manager peak_refresh_rate_default 120
device_config put display_manager refresh_rate_in_hbm_sunlight 120
device_config put display_manager refresh_rate_in_hbm_hdr 120
device_config put display_manager refresh_rate_in_high_zone 120
device_config put display_manager refresh_rate_in_low_zone 120

# Cấu hình Debug Properties cho Display & HWC
setprop debug.display.peak_refresh_rate 120
setprop debug.display.min_refresh_rate 120
setprop debug.display.max_refresh_rate 120
setprop debug.display.user_refresh_rate 120
setprop debug.display.default_refresh_rate 120
setprop debug.display.primary_refresh_rate 120
setprop debug.display.refresh_rate 120
setprop debug.display.refresh_rate_limit 0
setprop debug.hwui.peak_refresh_rate 120
setprop debug.hwui.min_refresh_rate 120
setprop debug.hwui.max_refresh_rate 120
setprop debug.hwui.user_refresh_rate 120
setprop debug.hwui.default_refresh_rate 120
setprop debug.hwui.refresh_rate_limit 0
setprop debug.hwc.peak_refresh_rate 120
setprop debug.hwc.min_refresh_rate 120
setprop debug.hwc.max_refresh_rate 120
setprop debug.hwc.user_refresh_rate 120
setprop debug.hwc.default_refresh_rate 120
setprop debug.hwuc.refresh_rate_limit 0
setprop debug.sf.touch_boost_refreshrate 120
setprop debug.sf.scroll_boost_refreshrate 120
setprop debug.peak_refresh_rate 120
setprop debug.min_refresh_rate 120
setprop debug.max_refresh_rate 120
setprop debug.lock_refresh_rate 120
setprop debug.refresh_rate.min_fps 120
setprop debug.refresh_rate.max_fps 120
setprop debug.refresh_rate.peak_fps 120
settings put system db_screen_rate 2
settings put system miui_home_animation_rate 2
settings put system refresh_default_rate 120
settings put system default_refresh_rate 120
settings put system default_peak_refresh_rate 120
settings put system preferred_refresh_rate 1
settings put system default_refresh_mode 2
settings put system min_render_frame_rate 120
settings put system peak_render_frame_rate 120
settings put system min_refresh_rate 120
settings put system max_refresh_rate 120
settings put system min_frame_rate 120
settings put system max_frame_rate 120
settings put system user_refresh_rate 120
settings put system peak_refresh_rate 120
settings put system user_min_refresh_rate 120
settings put system user_peak_refresh_rate 120
settings put system miui_refresh_rate 120
settings put system last_tran_refresh_mode_in_refresh_setting 120
settings put system tran_need_recovery_refresh_mode 120
settings put system tran_refresh_mode 120
settings put system refresh_rate 120
settings put system sem_power_mode_refresh_rate 2,2,2,2,2
settings put system sem_power_mode_refresh_rate_cover 2,2,2,2,2
settings put system is_smart_fps 0
settings put system power_save_pre_refresh_state 2
settings put system power_save_screen_refresh_rate 0
settings put system power_save_coloros_screen_refresh_rate 2
settings put system multi_device_decrease_refresh_rate_backup -1
settings put system fps_boost_mode 1
settings put system tran_settings_long_battery_swith_60hz 0
settings put system tran_low_battery_60hz_refresh_rate_support 0
settings put system thermal_limit_refresh_rate 120
settings put secure miui_refresh_rate 120
settings put secure support_highfps 1
settings put secure user_refresh_rate 120
settings put secure refresh_rate_mode 2
settings put secure oplus_customize_screen_refresh_rate 120
settings put secure oplus_customize_min_refresh_rate 120
settings put secure oplus_customize_peak_refresh_rate 120
settings put secure coloros_screen_refresh_rate 3
settings put secure multi_device_decrease_refresh_rate_backup -1
settings put secure oplus_refreshrate_override 0
settings put secure sys_force_60Hz 0
settings put global vivo_screen_refresh_rate_mode 2
settings put global ScreenRefreshRateController_resultFps 120
settings put global oneplus_screen_refresh_rate 0
settings put global 6ecb9657_screen_refresh_rate 120
settings put global sem_power_mode_refresh_rate 2,2,2,2,2
settings put global sem_power_mode_refresh_rate_cover 2,2,2,2,2
settings put global fps_divisor 0
settings put global development_render_shadows_in_compositor 1
settings put global graphic_hdr_settings 0
settings put global user_disabled_hdr_formats 1
settings put global va_hdr_mode 0
settings put system tran_default_color_mode 1
settings put system trans_dynamic_applied_json {"android.theme.customization.adaptive_icon_shape":"com.theme.icondefaultshape","android.theme.customization.system_palette":"14C764","android.theme.customization.accent_color":"14C764","_applied_timestamp":1746886379752,"android.theme.customization.color_source":"preset","android.theme.customization.color_index":"2","android.theme.customization.theme_style":"RAINBOW","android.theme.customization.trans_color_type":"PRESET_COLOR","android.theme.customization.preset_name":"preset_brand_green"}
settings put global scaling_force 1
settings put global disable_window_blurs 0
settings put global burn_in_protection 0
cmd display dwb-set-cct 6500
# Caching
service call SurfaceFlinger 1040 i32 1 i64 $DISPLAY_ID
# Hardware Composer/Compesitor
service call SurfaceFlinger 1001 i32 1
service call SurfaceFlinger 1008 i32 0
# Setprop
setprop dev.pm.dyn_samplingrate 0
setprop dev.pm.dyn_sample_period 0
setprop debug.sf.dfps_max_fps 120
setprop debug.sf.dfps_min_fps 120
setprop debug.sf.dfps_peak_fps 120
setprop debug.hwui.profile.minframes 120
setprop debug.hwui.profile.peakframes 120
setprop debug.refresh_rate.max_fps 120
setprop debug.refresh_rate.peak_fps 120
setprop debug.sf.early_flush 1
setprop debug.sf.enable_deffered_req true
setprop debug.sf.nobg.exec 1
setprop debug.sf.unblock_presents true
setprop debug.sf.disable_hystart 1
setprop debug.overlay.resresh_surf_list false
setprop debug.sf.tupleSkipping true
setprop debug.hwui.disableVsync true
setprop debug.sf.no_wcg 1
setprop debug.sf.bundle_size 0
setprop persist.sys.fps.min 120
setprop persist.sys.fps.peak 120
setprop debug.sf.hwc.canUseABC 0
setprop debug.sf.ignore_hwc_physical_display_orientation false
setprop debug.egl.hw 1
setprop debug.sf.hw 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.auto.latch_unsignaled 0
setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.supports_desired_transition_mode 1
setprop debug.egl.profiler 1
setprop debug.egl.callstack 0
setprop debug.egl.finish 0
setprop debug.fb.rgb565 1
setprop debug.sf.fb_always_on 1
setprop debug.egl.changepixelformat RGB_565
setprop debug.sf.force_populate_color_modes true
setprop debug.sf.force_p3_to_srgb_oem true
setprop debug.sf.support_hdr_by_wide_color_gamut 0
setprop debug.sf.treat_170m_as_sRGB 1
setprop debug.hwui.8bit_hdr_headroom false
setprop debug.hwui.shadow_renderer monolite
setprop debug.hwui.use_gpu_pixel_buffers true
setprop debug.renderengine.graphite false
setprop debug.mdpcomp.4k2kSplit 0
setprop debug.sys.osie.neednocompress 0
setprop debug.enable.sglscale 1
setprop debug.egl.native_scaling true
setprop debug.sf.enable_sdr_dimming 0
setprop debug.sf.enable_fb_ubwc 0
setprop debug.gralloc.enable_fb_ubwc 0
setprop debug.gralloc.gfx_ubwc_disable 1
setprop debug.gralloc.map_fb_memory 0
setprop debug.gralloc.disable_ahardware_buffer 0
setprop debug.ui.default_mapper 2
setprop debug.ui.default_gralloc 2
setprop debug.gfx.driver 0
setprop debug.gfx.early_z 0
setprop debug.sf.use_background_blur true
setprop debug.renderengine.restore_blur_step true
setprop debug.composition.type c2d
setprop debug.mediatek.composition.type c2d
setprop debug.composition.7x27A.type c2d
setprop debug.composition.7x25A.type c2d
setprop debug.composition.8x25.type c2d
setprop debug.hwc.force_gpu 1
setprop debug.sf.disable_hwc 0
setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.disable_hwc_vds 0
setprop debug.hwui.force_gpu_for_2d true
setprop debug.hwui.profile_gpu_render true
setprop debug.hwc.compose_level 1
setprop debug.sf.predict_hwc_composition_strategy 1
setprop debug.sf.gpu_comp_tiling 1
setprop debug.sf.force_cursor_gpu 1
setprop debug.hwc.dynThreshold 0.0
setprop debug.hwc.asyncdisp 1
setprop debug.hwc.bq_count 3
setprop debug.hwc.otf 1
setprop debug.hwui.hwc.skip_validate 1
setprop debug.disable_skip_validate 0
setprop debug.mdpcomp.mixedmode.disable false
setprop debug.mdpcomp.maxpermixer -1
setprop debug.mdpcomp.maxlayer 4
setprop debug.sf.disable_hwc_blit false
setprop debug.egl.buffcount 4
setprop debug.hwc.dynThreshold 2.5
setprop debug.hwc.disabletonemapping false
setprop debug.hwc_dump_en 1
setprop debug.sf.hwc_service_name default
setprop debug.sf.enable_cached_set_render_scheduling true
setprop debug.sf.cached_set_render_duration_ns 0
setprop debug.sf.cached_set_max_defer_render_attmpts false
setprop debug.sf.enable_planner_prediction true
setprop debug.sf.enable_hole_punch_pip false
setprop debug.sf.enable_layer_command_batching 1
setprop debug.egl.blobcache.multifile true
setprop debug.egl.blobcache.multifile_limit 33554432
setprop debug.mdpcomp.cache 0
setprop debug.hwui.enable_bp_cache true
setprop debug.hwui.use_small_cache 1
setprop debug.hwui.disable_gpu_cache false
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.enable_layer_caching 1
setprop debug.sf.layer_caching_active_layer_timeout_ms 0
setprop debug.sf.prime_shader_cache.hole_punch false
setprop debug.sf.prime_shader_cache.solid_layers false
setprop debug.sf.prime_shader_cache.solid_dimmed_layers false
setprop debug.sf.prime_shader_cache.image_dimmed_layers false
setprop debug.sf.prime_shader_cache.image_layers false
setprop debug.sf.prime_shader_cache.clipped_layers false
setprop debug.sf.prime_shader_cache.shadow_layers false
setprop debug.sf.prime_shader_cache.pip_image_layers false
setprop debug.sf.prime_shader_cache.transparent_image_dimmed_layers false
setprop debug.sf.prime_shader_cache.clipped_dimmed_image_layers false
setprop debug.sf.cache_source_crop_only_moved 0
setprop debug.sf.edge_extension_shader true
setprop debug.sf.enable_legacy_frontend false
setprop debug.sf.enable_layer_lifecycle_manager true
setprop debug.sf.high_speed_scroll_factor 25
setprop debug.sf.use_frame_rate_priority 1
setprop debug.hwui.fps_divisor 0
setprop debug.fps.render.fast 1
setprop debug.sf.showupdates 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.showfps 0
setprop debug.sf.show_refresh_rate_overlay_spinner 0
setprop debug.sf.show_refresh_rate_overlay_render_rate 0
setprop debug.sf.show_refresh_rate_overlay_in_middle 0
setprop debug.hwui.disable_draw_defer true
setprop debug.hwui.disable_draw_reorder true
setprop debug.sf.treble_testing_override false
setprop debug.refresh_rate.view_override 1
setprop debug.sf.defer_refresh_rate_when_off 0
setprop debug.sf.use_content_detection_v2 false
setprop debug.sf.enable_vrr_config 0
setprop debug.sf.refreshrate_multi_group 0
setprop debug.sf.frame_rate_category_mrr 0
setprop debug.mediatek.high_frame_rate_multiple_display_mode 0
setprop debug.sf.enable_refresh_rate_restriction_for_app_switch 0
setprop debug.graphics.game_default_frame_rate.disabled true
setprop debug.sf.default_touch_timer_ms 0
setprop debug.sf.set_touch_timer_ms 0
setprop debug.touchscreen.latency.scale 0.1
setprop debug.tracing.block_touch_buffer 0
setprop debug.sf.luma_sampling 0
setprop debug.sf.region_sampling_timer_timeout_ns 0
setprop debug.sf.region_sampling_period_ns 0
setprop debug.sf.max_frame_latency 1
setprop debug.sf.layer_smoothness 1
setprop debug.choreographer.frametime false
setprop debug.choreographer.skipwarning false
setprop debug.choreographer.callback 0
setprop debug.choreographer.vsync false
setprop debug.choreographer.pipeline false
setprop debug.hwui.disable_vsync true
setprop debug.cpurend.vsync false
setprop debug.gpurend.vsync false
setprop debug.hwui.force_no_vsync true
setprop debug.hwui.skip_vsync true
setprop debug.hwc.fakevsync 0
setprop debug.hwc.logvsync 0
setprop debug.hwc.force_gpu_vsync false
setprop debug.sf.hwc_hotplug_error_via_neg_vsync 0
setprop debug.sf.hwc_hdcp_via_neg_vsync 0
setprop debug.sf.no_hw_vsync 1
setprop debug.sf.vsync_reactor false
setprop debug.sf.vsync_reactor_ignore_present_fences 0
setprop debug.sf.show_predicted_vsync false
setprop debug.sf.swaprect 1
setprop debug.egl.swapinterval 0
setprop debug.gr.swapinterval 0
setprop debug.sf.swapinterval 0
setprop debug.oculus.swapInterval 0
setprop debug.gr.numframebuffers 3
setprop debug.sf.numframebuffers 3
setprop debug.sf.enable_advanced_sf_phase_offset 0
setprop debug.sf.use_phase_offsets_as_durations 0
setprop debug.sf.phase_offset_threshold_ns 0
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 0
setprop debug.sf.early_phase_offset_ns 0
setprop debug.sf.early_app_phase_offset_ns 0
setprop debug.sf.early_gl_phase_offset_ns 0
setprop debug.sf.early_gl_app_phase_offset_ns 0
setprop debug.sf.high_fps_late_sf_phase_offset_ns 0
setprop debug.sf.high_fps_early_phase_offset_ns 0
setprop debug.sf.high_fps_early_gl_phase_offset_ns 0
setprop debug.sf.high_fps_late_app_phase_offset_ns 0
setprop debug.sf.early.app.duration 0
setprop debug.sf.earlyGl.app.duration 0
setprop debug.sf.early.sf.duration 0
setprop debug.sf.earlyGl.sf.duration 0
setprop debug.sf.high_fps.late.sf.duration 0
setprop debug.sf.high_fps.late.app.duration 0
setprop debug.sf.high_fps.early.sf.duration 0
setprop debug.sf.high_fps.early.app.duration 0
setprop debug.sf.high_fps.earlyGl.sf.duration 0
setprop debug.sf.high_fps.earlyGl.app.duration 0
setprop debug.sf.high_fps.hwc.min.duration 0
setprop debug.sf.60_fps.late.sf.duration 0
setprop debug.sf.60_fps.late.app.duration 0
setprop debug.sf.60_fps.early.sf.duration 0
setprop debug.sf.60_fps.early.app.duration 0
setprop debug.sf.60_fps.earlyGl.sf.duration 0
setprop debug.sf.60_fps.earlyGl.app.duration 0
setprop debug.sf.120_fps.late.sf.duration 0
setprop debug.sf.120_fps.late.app.duration 0
setprop debug.sf.120_fps.early.sf.duration 0
setprop debug.sf.120_fps.early.app.duration 0
setprop debug.sf.120_fps.earlyGl.sf.duration 0
setprop debug.sf.120_fps.earlyGl.app.duration 0
setprop debug.sf.120_fps.late.sf.duration 0
setprop debug.sf.120_fps.late.app.duration 0
setprop debug.sf.120_fps.early.sf.duration 0
setprop debug.sf.120_fps.early.app.duration 0
setprop debug.sf.120_fps.earlyGl.sf.duration 0
setprop debug.sf.120_fps.earlyGl.app.duration 0
setprop debug.sf.144_fps.late.sf.duration 0
setprop debug.sf.144_fps.late.app.duration 0
setprop debug.sf.144_fps.early.sf.duration 0
setprop debug.sf.144_fps.early.app.duration 0
setprop debug.sf.144_fps.earlyGl.sf.duration 0
setprop debug.sf.144_fps.earlyGl.app.duration 0
setprop debug.sf.165_fps.late.sf.duration 0
setprop debug.sf.165_fps.late.app.duration 0
setprop debug.sf.165_fps.early.sf.duration 0
setprop debug.sf.165_fps.early.app.duration 0
setprop debug.sf.165_fps.earlyGl.sf.duration 0
setprop debug.sf.165_fps.earlyGl.app.duration 0
setprop debug.sf.185_fps.late.sf.duration 0
setprop debug.sf.185_fps.late.app.duration 0
setprop debug.sf.185_fps.early.sf.duration 0
setprop debug.sf.185_fps.early.app.duration 0
setprop debug.sf.185_fps.earlyGl.sf.duration 0
setprop debug.sf.185_fps.earlyGl.app.duration 0
setprop debug.sf.240_fps.late.sf.duration 0
setprop debug.sf.240_fps.late.app.duration 0
setprop debug.sf.240_fps.early.sf.duration 0
setprop debug.sf.240_fps.early.app.duration 0
setprop debug.sf.240_fps.earlyGl.sf.duration 0
setprop debug.sf.240_fps.earlyGl.app.duration 0
setprop debug.sf.hwc.min.duration 0
setprop debug.sf.late.app.duration 0
setprop debug.sf.late.sf.duration 0
setprop debug.sf.1hz_nit_lower_limit 0
setprop debug.sf.10hz_nit_lower_limit 0
setprop debug.javafx.animation.framerate 120
setprop debug.oculus.refreshRate 120
setprop debug.sf.frame_rate_multiple_threshold 120
setprop debug.sf_frame_rate_multiple_fences 120
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 120
setprop debug.redroid.fps 120
setprop debug.hwui.profile.maxframes 120
setprop debug.OVRPlugin.systemDisplayFrequency 120
setprop debug.sf.scroll_boost_refreshrate 120
setprop debug.sf.touch_boost_refreshrate 120
setprop debug.sf.touch_on_blank_not_boost_refreshrate 120
setprop debug.refresh_rate.min_fps "0,60,120,120,144,165,185,240"
setprop persist.sys.egl.swapinterval 0
setprop persist.sys.gr.swapinterval 0
setprop persist.sys.sf.swapinterval 0
setprop persist.sys.debug.egl.swapinterval 0
setprop persist.sys.debug.gr.swapinterval 0
setprop persist.sys.debug.sf.swapinterval 0
setprop persist.sys.vsync_optimization_enable false
setprop persist.sys.hwui.dyn_vsync 0
setprop persist.sys.vsync 0
setprop persist.sys.surfaceflinger.idle_reduce_framerate_enable false
setprop persist.sys.first.frame.accelerates true
setprop persist.sys.fpsctrl.enable 0
setprop persist.sys.autofps.mode 0
setprop persist.sys.smartfps 0
setprop persist.sys.use_gpu_fps_counter 1
setprop persist.sys.refresh_rate 120
setprop persist.sys.NV_FPSLIMIT 120
setprop persist.sys.fps.max 120
setprop persist.sys.tran.brightness.gammalinear.convert 1
setprop persist.sys.bluelight.default 128
setprop persist.sys.resolutiontuner.enable false
setprop persist.sys.textureview_optimization.enable false
setprop persist.sys.disable_sdr_dimming true
setprop persist.sys.colorgamut.mode 0
setprop persist.sys.composition.type c2d
setprop persist.sys.hdr_dimmer_for_video_supported false
setprop persist.sys.gallery_hdr_boost_max_factor 0.0
setprop persist.sys.background_blur_keyguard_disabled false
setprop persist.sys.background_blur_status_default true
setprop persist.sys.background_blur_supported true
setprop persist.sys.screen_anti_burn_enabled false
setprop persist.sys.display_srgb 1
setprop persist.sys.sf.color_saturation 1.0
setprop persist.sys.sf.native_mode 1
setprop persist.sys.colortemp.minred 255
setprop persist.sys.colortemp.mingreen 238
setprop persist.sys.colortemp.minblue 192
setprop persist.sys.colortemp.maxred 224
setprop persist.sys.colortemp.maxgreen 236
setprop persist.sys.colortemp.maxblue 255
setprop persist.sys.force_sw_gles 1
setprop persist.sys.use_gpu_fps_counter 1
setprop persist.sys.hwcomposer.force_gpu 1
setprop persist.sys.rendercomposer.enable true
setprop persist.sys.sf.enable_hwc_vds 1
setprop persist.sys.gpu.working_thread_priority true
setprop persist.sys.force_hw_ui true
setprop persist.sys.ui.hw 1
setprop persist.sys.ui.rendering 1 
setprop persist.sys.gpu.rendering 1
setprop persist.sys.downscale.disable false
setprop persist.sys.use_16bpp_alpha true
setprop persist.sys.ui.enable_16bit_format true
setprop persist.sys.force_highendgfx false
setprop sys.hwc.mdp_downscale_enable true
setprop sys.output.16bit true
setprop sys.fb.bits 16
setprop sys.transsion.nvcolor A91
setprop sys.displayfeature.entry.enable true
setprop sys.displayfeature.hidl true
setprop sys.surfaceflinger.aggressivevsync false
setprop sys.surfaceflinger.idle_reduce_framerate_enable no
setprop sys.hangouts.fps -1
setprop sys.refresh.dirty 0
setprop sys.fps_unlock_allowed 120
# Reset Refresh Rate
settings put system peak_refresh_rate 60
settings put system min_refresh_rate 60
settings delete secure refresh_rate_mode
settings delete system user_refresh_rate
settings delete secure user_refresh_rate
settings delete secure miui_refresh_rate
settings delete system fps_limit
settings delete system max_render_frame_rate
settings delete global min_fps
settings delete global max_fps
settings delete system thermal_limit_refresh_rate
settings delete system peak_refresh_rate
settings delete system min_refresh_rate
settings delete system max_refresh_rate
settings delete system user_refresh_rate
settings delete system default_refresh_rate
settings delete system refresh_rate
settings delete system preferred_refresh_rate
settings delete system miui_refresh_rate
settings delete system thermal_limit_refresh_rate
settings delete system tran_refresh_mode
settings delete system tran_need_recovery_refresh_mode
settings delete system refresh_rate_policy
settings delete system ext_force_refresh_rate_list
settings delete system db_screen_rate
settings delete global preferred_refresh_rate
settings delete global user_preferred_refresh_rate
settings delete secure user_refresh_rate
settings delete secure max_refresh_rate
settings delete secure miui_refresh_rate
settings delete secure refresh_rate_mode
device_config delete display_manager peak_refresh_rate_default
device_config delete display_manager refresh_rate_in_hbm_sunlight
device_config delete display_manager refresh_rate_in_hbm_hdr
device_config delete display_manager refresh_rate_in_high_zone
device_config delete display_manager refresh_rate_in_low_zone
setprop debug.display.peak_refresh_rate ""
setprop debug.display.min_refresh_rate ""
setprop debug.display.max_refresh_rate ""
setprop debug.display.user_refresh_rate ""
setprop debug.display.default_refresh_rate ""
setprop debug.display.primary_refresh_rate ""
setprop debug.display.refresh_rate ""
setprop debug.display.refresh_rate_limit ""
setprop debug.hwui.peak_refresh_rate ""
setprop debug.hwui.min_refresh_rate ""
setprop debug.hwui.max_refresh_rate ""
setprop debug.hwui.user_refresh_rate ""
setprop debug.hwui.default_refresh_rate ""
setprop debug.hwui.refresh_rate_limit ""
setprop debug.hwc.peak_refresh_rate ""
setprop debug.hwc.min_refresh_rate ""
setprop debug.hwc.max_refresh_rate ""
setprop debug.hwc.user_refresh_rate ""
setprop debug.hwc.default_refresh_rate ""
setprop debug.hwuc.refresh_rate_limit ""
setprop debug.sf.touch_boost_refreshrate ""
setprop debug.sf.scroll_boost_refreshrate ""
setprop debug.peak_refresh_rate ""
setprop debug.min_refresh_rate ""
setprop debug.max_refresh_rate ""
setprop debug.lock_refresh_rate ""
setprop debug.refresh_rate.min_fps ""
setprop debug.refresh_rate.max_fps ""
setprop debug.refresh_rate.peak_fps ""

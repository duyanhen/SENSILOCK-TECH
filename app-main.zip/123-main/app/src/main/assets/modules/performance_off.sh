settings delete global game_driver_all_apps
settings delete global game_driver_opt_out_apps
settings delete global game_driver_prerelease_allowlist
settings delete global hwui_force_gpu
settings delete global force_hw_ui
settings delete global disable_vsync
settings delete global persist.sys.NV_CUSTOM_GAME_FPS
settings delete global sustained_performance_mode_enabled
cmd power set-fixed-performance-mode-enabled false
cmd power set-adaptive-power-saver-enabled true
cmd thermalservice reset
pm enable com.miui.powerkeeper
settings delete system POWER_PERFORMANCE_MODE_OPEN
settings delete system high_performance_mode_on
settings delete secure speed_mode_enable
settings delete global miui_performance_mode
settings delete global performance_profile
settings delete system sem_performance_mode
settings delete system sem_turbo_mode
settings delete global cpu_gpu_constants
settings delete global dynamic_frequency_scaling_constants
settings delete global gaming_power_constants
settings delete system cpu_boost_input_boost_ms
settings delete system cpu_boost_powerkey_input_boost_ms
settings delete system cpu_boost_input_boost_enabled
settings delete system cpu_set_effective_cpus
settings delete system cpu_set_foreground_cpus
settings delete system cpu_set_top-app_cpus
settings delete system peak_refresh_rate
settings delete system min_refresh_rate
settings delete system user_refresh_rate
settings delete global force_high_refresh_rate
settings delete global adaptive_refresh_rate_enabled
settings delete system adaptive_refresh_rate
settings delete system exact_refresh_rate_enabled
settings delete system display_frequency_forced
settings delete system fps_limit
setprop debug.sf.frame_rate_multiple_threshold ""
setprop debug.sf.scroll_boost_refreshrate ""
setprop debug.sf.touch_boost_refreshrate ""
setprop debug.hwui.fpslimit ""
setprop debug.hwui.fps_limit ""
setprop debug.refresh_rate.min_fps ""
setprop debug.refresh_rate.max_fps ""
setprop debug.refresh_rate.peak_fps ""
setprop debug.hwui.force_gpu ""
setprop debug.hwui.use_fast_path ""
setprop debug.hwui.enable_threaded_render ""
setprop debug.hwui.optimize_rendering ""
setprop debug.hwui.enable_partial_render ""
setprop debug.hwui.disable_vsync ""
setprop debug.sf.multithreaded_present ""
setprop debug.sf.enable_hwc_vds ""
setprop debug.cpurend.vsync ""
setprop debug.performance.tuning ""
setprop debug.egl.hw ""
setprop debug.sf.hw ""
